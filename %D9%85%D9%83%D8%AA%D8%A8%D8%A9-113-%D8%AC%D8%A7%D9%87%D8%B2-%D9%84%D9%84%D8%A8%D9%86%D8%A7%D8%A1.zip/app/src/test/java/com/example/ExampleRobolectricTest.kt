package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Product
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("مكتبة 113", appName)
  }

  @Test
  fun `product price calculation is accurate`() {
    val product = Product(
      id = 1,
      name = "كراس 96 صفحة",
      category = "كراريس وأغلفة",
      priceDzd = 95.0,
      description = "كراس مدرسي",
      inStock = true
    )
    val quantity = 3
    val total = product.priceDzd * quantity
    assertEquals(285.0, total, 0.01)
  }
}
