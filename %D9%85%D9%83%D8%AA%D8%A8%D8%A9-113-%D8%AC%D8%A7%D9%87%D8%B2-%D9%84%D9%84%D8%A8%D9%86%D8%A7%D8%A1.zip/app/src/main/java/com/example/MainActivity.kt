package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AdminModeDialog
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.FlexyBillsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JobsEduScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.StoreScreen
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: MainViewModel by viewModels()

  @OptIn(ExperimentalMaterial3Api::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        // Enforce native Arabic Right-To-Left layout
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          MaktabatApp(viewModel)
        }
      }
    }
  }
}

sealed class NavTab(val index: Int, val title: String, val icon: ImageVector) {
  object Home : NavTab(0, "الرئيسية", Icons.Default.Home)
  object Services : NavTab(1, "الخدمات", Icons.Default.Print)
  object Store : NavTab(2, "المتجر", Icons.Default.ShoppingCart)
  object JobsEdu : NavTab(3, "التوظيف والدروس", Icons.Default.School)
  object Flexy : NavTab(4, "فليكسي وفواتير", Icons.Default.PhoneAndroid)
  object AiAssistant : NavTab(5, "المستشار الذكي", Icons.Default.AutoAwesome)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaktabatApp(viewModel: MainViewModel) {
  val context = LocalContext.current
  var currentTabIndex by remember { mutableIntStateOf(0) }
  val snackbarHostState = remember { SnackbarHostState() }
  val isAdminMode by viewModel.isAdminMode.collectAsState()
  val cart by viewModel.cart.collectAsState()
  val cartCount = cart.values.sumOf { it.quantity }

  var showAdminDialog by remember { mutableStateOf(false) }

  // Listen to snackbar messages from ViewModel
  LaunchedEffect(Unit) {
    viewModel.snackbarMessage.collect { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  // Handle system back button to pop to Home
  BackHandler(enabled = currentTabIndex != 0) {
    currentTabIndex = 0
  }

  if (showAdminDialog) {
    AdminModeDialog(
      currentStatus = isAdminMode,
      onDismiss = { showAdminDialog = false },
      onToggle = { enabled ->
        viewModel.toggleAdminMode(enabled)
      }
    )
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        navigationIcon = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 12.dp)
          ) {
            Surface(
              shape = CircleShape,
              color = NavyPrimary.copy(alpha = 0.12f),
              modifier = Modifier.size(38.dp)
            ) {
              Image(
                painter = painterResource(id = R.drawable.ic_maktabat_113),
                contentDescription = "شعار مكتبة 113",
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
              )
            }
          }
        },
        title = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "مكتبة 113",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
              )
              if (isAdminMode) {
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = AmberGold
                ) {
                  Text(
                    text = "المدير",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
            }
            Text(
              text = "حي 113 • 0664751271",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 11.sp
            )
          }
        },
        actions = {
          // Direct dial button
          IconButton(
            onClick = {
              val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:0664751271")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
              }
              try {
                context.startActivity(intent)
              } catch (e: Exception) {
                Toast.makeText(context, "0664751271", Toast.LENGTH_SHORT).show()
              }
            }
          ) {
            Icon(
              imageVector = Icons.Default.Phone,
              contentDescription = "اتصال بمكتبة 113",
              tint = NavyPrimary
            )
          }

          // Admin mode toggle button
          IconButton(
            onClick = { showAdminDialog = true },
            modifier = Modifier.testTag("admin_settings_btn")
          ) {
            Icon(
              imageVector = Icons.Default.AdminPanelSettings,
              contentDescription = "وضع صاحب المكتبة",
              tint = if (isAdminMode) AmberGold else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      )
    },
    bottomBar = {
      val tabs = listOf(
        NavTab.Home,
        NavTab.Services,
        NavTab.Store,
        NavTab.JobsEdu,
        NavTab.Flexy,
        NavTab.AiAssistant
      )

      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
      ) {
        tabs.forEach { tab ->
          val isSelected = currentTabIndex == tab.index
          NavigationBarItem(
            selected = isSelected,
            onClick = { currentTabIndex = tab.index },
            icon = {
              if (tab is NavTab.Store && cartCount > 0) {
                BadgedBox(
                  badge = {
                    Badge(containerColor = AmberGold, contentColor = Color.White) {
                      Text(cartCount.toString(), fontSize = 9.sp)
                    }
                  }
                ) {
                  Icon(tab.icon, contentDescription = tab.title)
                }
              } else {
                Icon(tab.icon, contentDescription = tab.title)
              }
            },
            label = {
              Text(
                text = tab.title,
                fontSize = 10.sp,
                maxLines = 1,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = NavyPrimary,
              selectedTextColor = NavyPrimary,
              indicatorColor = NavyContainer,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_tab_${tab.index}")
          )
        }
      }
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      when (currentTabIndex) {
        0 -> HomeScreen(
          viewModel = viewModel,
          onNavigateToTab = { currentTabIndex = it }
        )
        1 -> ServicesScreen(viewModel = viewModel)
        2 -> StoreScreen(viewModel = viewModel)
        3 -> JobsEduScreen(viewModel = viewModel)
        4 -> FlexyBillsScreen(viewModel = viewModel)
        5 -> AiAssistantScreen(viewModel = viewModel)
      }
    }
  }
}
