package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ServicesScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: خدمات الطباعة والبحوث, 1: التسجيلات والملفات

  Column(modifier = modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = NavyPrimary
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("خدمات الطباعة والبحوث", fontWeight = FontWeight.Bold) },
        icon = { Icon(Icons.Default.Print, contentDescription = null) }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("التسجيلات الإدارية والسكن", fontWeight = FontWeight.Bold) },
        icon = { Icon(Icons.Default.Assignment, contentDescription = null) }
      )
    }

    when (selectedTab) {
      0 -> PrintingAndResearchTab(viewModel)
      1 -> RegistrationsAndFormsTab(viewModel)
    }
  }
}

// --- Tab 1: خدمات الطباعة والبحوث وحاسبة التكلفة ---
@Composable
fun PrintingAndResearchTab(viewModel: MainViewModel) {
  var pageCount by remember { mutableStateOf("10") }
  var isColor by remember { mutableStateOf(false) } // false = Black/White (5 DZD), true = Color (20 DZD)
  var isDoubleSided by remember { mutableStateOf(false) }
  var bindingType by remember { mutableStateOf("بدون تغليف") } // "بدون تغليف", "سلك بلاستيكي Spiral (150 دج)", "تغليف حراري فاخر (350 دج)"

  var clientName by remember { mutableStateOf("") }
  var clientPhone by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var selectedServiceTitle by remember { mutableStateOf("طباعة مستندات وبحوث") }

  // Calculation logic (DZD)
  val pages = pageCount.toIntOrNull() ?: 0
  val costPerPage = if (isColor) 20.0 else 5.0
  val basePrintCost = pages * costPerPage
  val bindingCost = when (bindingType) {
    "سلك بلاستيكي Spiral (150 دج)" -> 150.0
    "تغليف حراري فاخر (350 دج)" -> 350.0
    else -> 0.0
  }
  val totalEstimateDzd = basePrintCost + bindingCost

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Services Cards
    item {
      Text(
        text = "خدمات الإعلام الآلي والمكتبة",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(8.dp))
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ServiceInfoRow(
          title = "طباعة المستندات والبحوث الجامعية",
          desc = "طباعة ليزرية عالية الدقة أبيض وأسود وبالألوان لجميع الأحجام (A4, A3).",
          icon = Icons.Default.Print,
          isSelected = selectedServiceTitle == "طباعة مستندات وبحوث",
          onClick = { selectedServiceTitle = "طباعة مستندات وبحوث" }
        )
        ServiceInfoRow(
          title = "كتابة وتنسيق المذكرات والتقارير",
          desc = "كتابة احترافية على Word، تنسيق الجداول والفهارس، وتهميش المراجع.",
          icon = Icons.Default.MenuBook,
          isSelected = selectedServiceTitle == "كتابة وتنسيق المذكرات والتقارير",
          onClick = { selectedServiceTitle = "كتابة وتنسيق المذكرات والتقارير" }
        )
        ServiceInfoRow(
          title = "استخراج الفروض والدروس والاختبارات",
          desc = "تجهيز وطباعة مواضيع الامتحانات والفروض لجميع الأطوار والسنوات.",
          icon = Icons.Default.School,
          isSelected = selectedServiceTitle == "استخراج الفروض والدروس والاختبارات",
          onClick = { selectedServiceTitle = "استخراج الفروض والدروس والاختبارات" }
        )
      }
    }

    // Interactive Print Calculator
    item {
      ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Calculate, contentDescription = null, tint = NavyPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "حاسبة تكلفة الطباعة والتغليف الفورية",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = NavyPrimary
            )
          }

          OutlinedTextField(
            value = pageCount,
            onValueChange = { pageCount = it },
            label = { Text("عدد الصفحات التقريبي") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("calc_page_count")
          )

          Text("نوع الطباعة:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
              selected = !isColor,
              onClick = { isColor = false },
              label = { Text("أبيض وأسود (5 دج/صفحة)") },
              leadingIcon = if (!isColor) { { Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp)) } } else null
            )
            FilterChip(
              selected = isColor,
              onClick = { isColor = true },
              label = { Text("ألوان ليزر (20 دج/صفحة)") },
              leadingIcon = if (isColor) { { Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp)) } } else null
            )
          }

          Text("خيارات التغليف والتجليد:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("بدون تغليف", "سلك بلاستيكي Spiral (150 دج)", "تغليف حراري فاخر (350 دج)").forEach { b ->
              FilterChip(
                selected = bindingType == b,
                onClick = { bindingType = b },
                label = { Text(b) },
                leadingIcon = if (bindingType == b) { { Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp)) } } else null
              )
            }
          }

          // Total estimate display
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = AmberGold.copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "التكلفة التقديرية الإجمالية:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${totalEstimateDzd.toInt()} دج",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = AmberGold
              )
            }
          }
        }
      }
    }

    // Direct Service Request Submission Form
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "إرسال طلب تجهيز أو طباعة مسبقاً",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "أرسل تفاصيل بحثك أو مذكرتك وسيتكفل طاقم مكتبة 113 بتجهيزه لاستلامه جاهزاً دون انتظار!",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          OutlinedTextField(
            value = clientName,
            onValueChange = { clientName = it },
            label = { Text("الاسم الكامل *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("req_name_input")
          )

          OutlinedTextField(
            value = clientPhone,
            onValueChange = { clientPhone = it },
            label = { Text("رقم الهاتف للتواصل *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("req_phone_input")
          )

          OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("عنوان البحث / الموضوع / تفاصيل الملف") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth().testTag("req_notes_input")
          )

          Button(
            onClick = {
              if (clientName.isNotBlank() && clientPhone.isNotBlank()) {
                val opts = "${if (isColor) "ألوان" else "أبيض وأسود"} - ${pages} صفحة - $bindingType"
                viewModel.submitServiceRequest(
                  serviceCategory = "خدمات الطباعة والبحوث",
                  serviceTitle = selectedServiceTitle,
                  customerName = clientName,
                  customerPhone = clientPhone,
                  details = notes.ifBlank { "طلب طباعة اعتيادي" },
                  options = opts,
                  estimatedPriceDzd = totalEstimateDzd
                )
                clientName = ""
                clientPhone = ""
                notes = ""
              }
            },
            enabled = clientName.isNotBlank() && clientPhone.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("submit_print_order_btn")
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إرسال الطلب لمكتبة 113")
          }
        }
      }
    }
  }
}

// --- Tab 2: التسجيلات والملفات الإدارية والسكن والمسابقات ---
@Composable
fun RegistrationsAndFormsTab(viewModel: MainViewModel) {
  val registrationTypes = listOf(
    RegistrationItem("مسابقة توظيف الأساتذة", "تسجيل إلكتروني وملء استمارات الوظيفة العمومية لقطاع التربية الوطنية", Icons.Default.Work, EmeraldGreen),
    RegistrationItem("مسابقة الأعوان الإداريين", "التسجيل في مسابقات متصرفين، أعوان إدارة، وأسلاك مشتركة", Icons.Default.Assignment, NavyPrimary),
    RegistrationItem("التكوين المهني والتمهين", "التسجيل بدورات أكتوبر وفيفري لشهادات تقني سامي وكفاءة مهنية", Icons.Default.School, AmberGold),
    RegistrationItem("التسجيل بالمراسلة (ONEFD)", "تأكيد التسجيل بالمراسلة لجميع المستويات وتحميل الفروض", Icons.Default.MenuBook, Color(0xFF7C3AED)),
    RegistrationItem("التسجيلات الجامعية (Progrès)", "تأكيد التسجيل للطلبة الجدد، طلبات الإيواء، المنحة والتحويلات", Icons.Default.School, NavyPrimary),
    RegistrationItem("شهادة التعليم المتوسط (BEM)", "تسجيل المترشحين المتمدرسين والأحرار واستخراج الاستدعاءات", Icons.Default.Assignment, AmberGold),
    RegistrationItem("شهادة البكالوريا (BAC)", "تسجيل الأحرار والنظاميين ومتابعة ملفات الديوان الوطني ONEC", Icons.Default.School, EmeraldGreen),
    RegistrationItem("سكنات عدل AADL والسكن الترقوي", "فتح حساب المكتتب، تحميل الوثائق، ومتابعة دراسة الطعون والملفات", Icons.Default.HomeWork, Color(0xFF0284C7))
  )

  var selectedType by remember { mutableStateOf(registrationTypes.first()) }
  var applicantName by remember { mutableStateOf("") }
  var applicantPhone by remember { mutableStateOf("") }
  var ninOrInfo by remember { mutableStateOf("") }
  var additionalNotes by remember { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "اختر نوع التسجيل المطلوب للتكفل به:",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    items(registrationTypes.size) { index ->
      val item = registrationTypes[index]
      val isSelected = selectedType.title == item.title
      ElevatedCard(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .clickable { selectedType = item },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
          containerColor = if (isSelected) NavyContainer else MaterialTheme.colorScheme.surface
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = CircleShape,
            color = item.color.copy(alpha = 0.15f),
            modifier = Modifier.size(44.dp)
          ) {
            Icon(
              imageVector = item.icon,
              contentDescription = null,
              tint = item.color,
              modifier = Modifier.padding(10.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = item.title,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = item.subtitle,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 11.sp
            )
          }
          if (isSelected) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NavyPrimary)
          }
        }
      }
    }

    // Application submission form
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "نموذج تقديم معلومات التسجيل: ${selectedType.title}",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
          )

          OutlinedTextField(
            value = applicantName,
            onValueChange = { applicantName = it },
            label = { Text("اسم ولقب المعني *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("app_name_input")
          )

          OutlinedTextField(
            value = applicantPhone,
            onValueChange = { applicantPhone = it },
            label = { Text("رقم الهاتف الشخصي *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("app_phone_input")
          )

          OutlinedTextField(
            value = ninOrInfo,
            onValueChange = { ninOrInfo = it },
            label = { Text("رقم التعريف الوطني NIN / أو رقم التسجيل القديم") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = additionalNotes,
            onValueChange = { additionalNotes = it },
            label = { Text("المستوى الدراسي، التخصص، أو أي وثائق متوفرة") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
          )

          Button(
            onClick = {
              if (applicantName.isNotBlank() && applicantPhone.isNotBlank()) {
                val details = "المعلومات: $ninOrInfo | ملاحظات: $additionalNotes"
                viewModel.submitServiceRequest(
                  serviceCategory = "التسجيلات الإدارية والمسابقات",
                  serviceTitle = selectedType.title,
                  customerName = applicantName,
                  customerPhone = applicantPhone,
                  details = details,
                  options = "متابعة وإيداع رسمي بمكتبة 113",
                  estimatedPriceDzd = 200.0
                )
                applicantName = ""
                applicantPhone = ""
                ninOrInfo = ""
                additionalNotes = ""
              }
            },
            enabled = applicantName.isNotBlank() && applicantPhone.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("submit_reg_request_btn")
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إرسال طلب التسجيل للتكفل به")
          }
        }
      }
    }
  }
}

data class RegistrationItem(
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val color: Color
)

@Composable
fun ServiceInfoRow(
  title: String,
  desc: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  ElevatedCard(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = if (isSelected) NavyContainer else MaterialTheme.colorScheme.surface
    )
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = NavyPrimary.copy(alpha = 0.12f),
        modifier = Modifier.size(40.dp)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = NavyPrimary,
          modifier = Modifier.padding(10.dp)
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = desc,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 11.sp
        )
      }
      if (isSelected) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NavyPrimary)
      }
    }
  }
}
