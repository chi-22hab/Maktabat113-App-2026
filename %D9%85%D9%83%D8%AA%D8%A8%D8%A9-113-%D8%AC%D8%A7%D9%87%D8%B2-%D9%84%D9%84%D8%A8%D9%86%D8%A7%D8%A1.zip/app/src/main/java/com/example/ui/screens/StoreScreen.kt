package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.ui.components.AddProductDialog
import com.example.ui.components.EditPriceDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.OnNavyContainer
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val products by viewModel.productsList.collectAsState()
  val selectedCategory by viewModel.selectedProductCategory.collectAsState()
  val searchQuery by viewModel.productSearchQuery.collectAsState()
  val cart by viewModel.cart.collectAsState()
  val isAdminMode by viewModel.isAdminMode.collectAsState()

  var productToEditPrice by remember { mutableStateOf<Product?>(null) }
  var showAddProductDialog by remember { mutableStateOf(false) }
  var showCartSheet by remember { mutableStateOf(false) }

  // Total cart count
  val cartItemCount = cart.values.sumOf { it.quantity }

  // Dialogs
  productToEditPrice?.let { prod ->
    EditPriceDialog(
      product = prod,
      onDismiss = { productToEditPrice = null },
      onSavePrice = { newPrice ->
        viewModel.updateProductPrice(prod.id, newPrice)
      }
    )
  }

  if (showAddProductDialog) {
    AddProductDialog(
      onDismiss = { showAddProductDialog = false },
      onAdd = { name, cat, price, desc, img ->
        viewModel.addNewProduct(name, cat, price, desc, img)
      }
    )
  }

  if (showCartSheet) {
    ModalBottomSheet(
      onDismissRequest = { showCartSheet = false },
      sheetState = rememberModalBottomSheetState()
    ) {
      CartBottomSheetContent(
        viewModel = viewModel,
        onClose = { showCartSheet = false }
      )
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.End
      ) {
        if (isAdminMode) {
          FloatingActionButton(
            onClick = { showAddProductDialog = true },
            containerColor = AmberGold,
            contentColor = Color.White,
            modifier = Modifier.testTag("admin_add_product_fab")
          ) {
            Icon(Icons.Default.Add, contentDescription = "إضافة منتج جديد")
          }
        }

        // Cart Floating Button with Badge
        FloatingActionButton(
          onClick = { showCartSheet = true },
          containerColor = NavyPrimary,
          contentColor = Color.White,
          modifier = Modifier.testTag("open_cart_fab")
        ) {
          BadgedBox(
            badge = {
              if (cartItemCount > 0) {
                Badge(containerColor = AmberGold, contentColor = Color.White) {
                  Text(cartItemCount.toString())
                }
              }
            }
          ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = "سلة المشتريات")
          }
        }
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.setProductSearchQuery(it) },
          placeholder = { Text("ابحث عن كراس، كتاب، قلم، عطر، حلويات...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { viewModel.setProductSearchQuery("") }) {
                Icon(Icons.Default.Clear, contentDescription = "مسح")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("store_search_input")
        )
      }

      // 2. Category Selector Chips
      item {
        val categories = listOf(
          ProductCategory.ALL.titleAr,
          ProductCategory.SCHOOL_SUPPLIES.titleAr,
          ProductCategory.NOTEBOOKS.titleAr,
          ProductCategory.BOOKS.titleAr,
          ProductCategory.COSMETICS.titleAr,
          ProductCategory.SWEETS.titleAr
        )

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(categories) { cat ->
            val isSelected = selectedCategory == cat
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.setProductCategory(cat) },
              label = { Text(cat) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = NavyPrimary,
                selectedLabelColor = Color.White
              )
            )
          }
        }
      }

      // 3. Admin Price Edit Notice
      if (isAdminMode) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AmberGold.copy(alpha = 0.12f)),
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, tint = AmberGold)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "وضع الإدارة مفعل: اضغط على زر القلم لتعديل سعر أي منتج وحفظه مباشرة في التطبيق.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 11.sp
              )
            }
          }
        }
      }

      // 4. Products List
      if (products.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.ShoppingBag,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.size(64.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "لا توجد منتجات مطابقة للبحث",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(products, key = { it.id }) { product ->
          ProductCard(
            product = product,
            isAdmin = isAdminMode,
            onAddToCart = { viewModel.addToCart(product) },
            onEditPrice = { productToEditPrice = product },
            onDelete = { viewModel.deleteProduct(product) }
          )
        }
      }
    }
  }
}

@Composable
fun ProductCard(
  product: Product,
  isAdmin: Boolean,
  onAddToCart: () -> Unit,
  onEditPrice: () -> Unit,
  onDelete: () -> Unit
) {
  ElevatedCard(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = NavyPrimary.copy(alpha = 0.1f)
          ) {
            Text(
              text = product.category,
              color = NavyPrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = product.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        // Editable Price Tag
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = AmberGold.copy(alpha = 0.15f),
          modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onEditPrice() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${product.priceDzd.toInt()} دج",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = AmberGold
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = "تعديل السعر",
              tint = AmberGold,
              modifier = Modifier.size(14.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = product.description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Quick "تعديل السعر" affordance as specifically requested
        TextButton(
          onClick = onEditPrice,
          modifier = Modifier.testTag("edit_price_btn_${product.id}")
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("تعديل السعر", fontSize = 12.sp)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (isAdmin) {
            IconButton(
              onClick = onDelete,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                Icons.Default.Delete,
                contentDescription = "حذف",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Button(
            onClick = onAddToCart,
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.testTag("add_to_cart_btn_${product.id}")
          ) {
            Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("أضف للسلة")
          }
        }
      }
    }
  }
}

@Composable
fun CartBottomSheetContent(
  viewModel: MainViewModel,
  onClose: () -> Unit
) {
  val cart by viewModel.cart.collectAsState()
  val total = viewModel.cartTotalPrice

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = NavyPrimary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "سلة مشترياتك من مكتبة 113",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
      if (cart.isNotEmpty()) {
        TextButton(onClick = { viewModel.clearCart() }) {
          Text("تفريغ", color = MaterialTheme.colorScheme.error)
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    if (cart.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text("السلة فارغة حالياً. تصفح المعروضات وأضف ما تحتاجه!")
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f, fill = false),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(cart.values.toList(), key = { it.product.id }) { item ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.product.name,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "${item.product.priceDzd.toInt()} دج × ${item.quantity} = ${(item.product.priceDzd * item.quantity).toInt()} دج",
                  style = MaterialTheme.typography.bodySmall,
                  color = AmberGold
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = { viewModel.updateCartQuantity(item.product.id, item.quantity - 1) },
                  modifier = Modifier.size(32.dp)
                ) {
                  Icon(Icons.Default.Remove, contentDescription = "إنقاص")
                }
                Text(
                  text = item.quantity.toString(),
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(
                  onClick = { viewModel.updateCartQuantity(item.product.id, item.quantity + 1) },
                  modifier = Modifier.size(32.dp)
                ) {
                  Icon(Icons.Default.Add, contentDescription = "زيادة")
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Total and Checkout
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = NavyContainer,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "المبلغ الإجمالي:",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = OnNavyContainer
          )
          Text(
            text = "${total.toInt()} دج",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Button(
        onClick = {
          viewModel.showMessage("تم تأكيد طلب الشراء بمبلغ ${total.toInt()} دج! سيتم تجهيزه لك بمكتبة 113.")
          viewModel.clearCart()
          onClose()
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("checkout_cart_btn")
      ) {
        Text("تأكيد وحجز الطلب للاستلام بحي 113", fontWeight = FontWeight.Bold)
      }
    }
  }
}
