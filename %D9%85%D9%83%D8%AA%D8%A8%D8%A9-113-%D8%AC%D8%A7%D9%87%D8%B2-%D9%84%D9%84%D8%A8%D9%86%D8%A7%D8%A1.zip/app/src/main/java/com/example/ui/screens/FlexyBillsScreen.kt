package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.OnNavyContainer
import com.example.ui.viewmodel.MainViewModel

@Composable
fun FlexyBillsScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedTab by remember { mutableIntStateOf(0) } // 0: خدمات الشحن والفواتير, 1: خانات الدفع المسبق والحسابات

  Column(modifier = modifier.fillMaxSize()) {
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = NavyPrimary
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("شحن فليكسي والفواتير", fontWeight = FontWeight.Bold) },
        icon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null) }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("حسابات الدفع المسبق", fontWeight = FontWeight.Bold) },
        icon = { Icon(Icons.Default.CreditCard, contentDescription = null) }
      )
    }

    when (selectedTab) {
      0 -> FlexyAndBillsOrderTab(viewModel)
      1 -> PrepaymentAccountsTab(context)
    }
  }
}

// --- Tab 1: شحن الرصيد وفليكسي وتسديد الفواتير ---
@Composable
fun FlexyAndBillsOrderTab(viewModel: MainViewModel) {
  val services = listOf(
    TelecomItem("موبيليس Mobilis", "فليكسي رصيد وعروض مبتسم وبيكس", Color(0xFF00843D), Icons.Default.PhoneAndroid),
    TelecomItem("جيزي Djezzy", "فليكسي فوري وعروض هايا وسبيد", Color(0xFFE30613), Icons.Default.PhoneAndroid),
    TelecomItem("أوريدو Ooredoo", "فليكسي وعروض لاغولا وجوازات إنترنت", Color(0xFFED1C24), Icons.Default.PhoneAndroid),
    TelecomItem("Idoom Fibre / 4G", "تجديد اشتراك الإنترنت اتصالات الجزائر", Color(0xFF005696), Icons.Default.Wifi),
    TelecomItem("فاتورة سونلغاز (Sonelgaz)", "تسديد فواتير الكهرباء والغاز لجميع العدادات", Color(0xFFEAB308), Icons.Default.ElectricBolt),
    TelecomItem("فاتورة المياه (ADE)", "دفع فواتير استهلاك المياه والتطهير", Color(0xFF0284C7), Icons.Default.WaterDrop),
    TelecomItem("الهاتف الثابت المنزلي", "دفع اشتراك الخط الثابت لاتصالات الجزائر", Color(0xFF6B7280), Icons.Default.ReceiptLong)
  )

  var selectedService by remember { mutableStateOf(services.first()) }
  var targetNumber by remember { mutableStateOf("") }
  var amountStr by remember { mutableStateOf("500") }
  var selectedCurrency by remember { mutableStateOf("دج (DZD)") }
  var selectedPaymentMethod by remember { mutableStateOf("بريدي موب (BaridiMob)") }
  var senderPhone by remember { mutableStateOf("") }
  var transactionRef by remember { mutableStateOf("") }

  val currencies = listOf("دج (DZD)", "أورو (€)", "دينار تونسي (TND)")
  val paymentMethods = listOf("بريدي موب (BaridiMob)", "حساب CCP / ECCP", "البطاقة الذهبية", "الدفع نقداً بالمكتبة")

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "اختر الخدمة أو الفليكسي المطلوب:",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    // Services Horizontal List
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(services) { serv ->
          val isSelected = selectedService.name == serv.name
          ElevatedCard(
            modifier = Modifier
              .width(200.dp)
              .clip(RoundedCornerShape(14.dp))
              .clickable { selectedService = serv },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.elevatedCardColors(
              containerColor = if (isSelected) NavyContainer else MaterialTheme.colorScheme.surface
            )
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Surface(
                shape = CircleShape,
                color = serv.brandColor.copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
              ) {
                Icon(
                  imageVector = serv.icon,
                  contentDescription = null,
                  tint = serv.brandColor,
                  modifier = Modifier.padding(8.dp)
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = serv.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = serv.desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // Order Details Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = "بيانات الطلب: ${selectedService.name}",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
          )

          OutlinedTextField(
            value = targetNumber,
            onValueChange = { targetNumber = it },
            label = {
              Text(
                if (selectedService.name.contains("فاتورة")) "رقم الفاتورة أو رقم الزبون / العداد *"
                else "رقم الهاتف / رقم الشريحة أو الحساب *"
              )
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("flexy_target_input")
          )

          // Amount + Currency Selector
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = amountStr,
              onValueChange = { amountStr = it },
              label = { Text("المبلغ المراد شحنه/دفعه *") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1.3f).testTag("flexy_amount_input")
            )

            Column(modifier = Modifier.weight(1.5f)) {
              Text("العملة:", style = MaterialTheme.typography.labelSmall)
              LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(currencies) { curr ->
                  FilterChip(
                    selected = selectedCurrency == curr,
                    onClick = { selectedCurrency = curr },
                    label = { Text(curr, fontSize = 11.sp) }
                  )
                }
              }
            }
          }

          // Payment Method Selector
          Text("وسيلة الدفع المسبق:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            paymentMethods.forEach { method ->
              FilterChip(
                selected = selectedPaymentMethod == method,
                onClick = { selectedPaymentMethod = method },
                label = { Text(method) }
              )
            }
          }

          OutlinedTextField(
            value = senderPhone,
            onValueChange = { senderPhone = it },
            label = { Text("رقم هاتفك للتأكيد والتواصل *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("flexy_sender_phone")
          )

          OutlinedTextField(
            value = transactionRef,
            onValueChange = { transactionRef = it },
            label = { Text("رقم الحوالة أو وصل الدفع (اختياري)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Button(
            onClick = {
              val amt = amountStr.toDoubleOrNull() ?: 0.0
              if (targetNumber.isNotBlank() && amt > 0 && senderPhone.isNotBlank()) {
                viewModel.submitFlexyOrder(
                  serviceName = selectedService.name,
                  targetIdentifier = targetNumber,
                  amount = amt,
                  currency = selectedCurrency,
                  paymentMethod = selectedPaymentMethod,
                  senderPhone = senderPhone,
                  transactionReference = transactionRef
                )
                targetNumber = ""
                senderPhone = ""
                transactionRef = ""
              }
            },
            enabled = targetNumber.isNotBlank() && (amountStr.toDoubleOrNull() ?: 0.0) > 0 && senderPhone.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("submit_flexy_order_btn")
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إرسال طلب الفليكسي / الدفع", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

// --- Tab 2: خانات الدفع المسبق والحسابات الرسمية لمكتبة 113 ---
@Composable
fun PrepaymentAccountsTab(context: Context) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "بيانات وحسابات الدفع المسبق لمكتبة 113",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "يمكنك الدفع مسبقاً عبر بريدي موب، الحساب البريدي الجاري، البطاقة الذهبية، أو بالعملات (الأورو والدينار التونسي):",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    // 1. BaridiMob
    item {
      AccountCard(
        title = "بريدي موب (BaridiMob)",
        identifierLabel = "رقم الـ RIP للتحويل المباشر:",
        identifierValue = "00799999002233445566",
        accountHolder = "مكتبة 113 (حي 113)",
        icon = Icons.Default.QrCode,
        badgeColor = EmeraldGreen,
        notes = "أدخل رقم الـ RIP في تطبيق بريدي موب للتحويل الفوري وأرسل لقطة الشاشة مع طلبك.",
        onCopy = { copyToClipboard(context, "00799999002233445566", "رقم RIP بريدي موب") }
      )
    }

    // 2. CCP / ECCP
    item {
      AccountCard(
        title = "الحساب البريدي الجاري (CCP / ECCP)",
        identifierLabel = "رقم الحساب البريدي والمفتاح (Clé):",
        identifierValue = "0022334455 / Clé 88",
        accountHolder = "حساب مكتبة 113 الرسمي",
        icon = Icons.Default.AccountBalance,
        badgeColor = AmberGold,
        notes = "متاح الدفع عبر مكاتب بريد الجزائر أو عبر منصة ECCP الرقمية.",
        onCopy = { copyToClipboard(context, "0022334455", "رقم الحساب البريدي") }
      )
    }

    // 3. Edahabia
    item {
      AccountCard(
        title = "البطاقة الذهبية (Edahabia)",
        identifierLabel = "خدمة الدفع بالبطاقة الذهبية:",
        identifierValue = "الدفع متاح عبر تطبيق بريدي موب أو مباشرة بالمكتبة",
        accountHolder = "متوفر جهاز الدفع الإلكتروني TPE بحي 113",
        icon = Icons.Default.CreditCard,
        badgeColor = NavyPrimary,
        notes = "تستطيع تمرير بطاقتك الذهبية مباشرة عند زيارتنا بحي 113 بدون عمولات إضافية.",
        onCopy = { copyToClipboard(context, "0664751271", "هاتف المكتبة") }
      )
    }

    // 4. Foreign Currencies: Euro & Tunisian Dinar
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = CircleShape,
              color = Color(0xFF7C3AED).copy(alpha = 0.12f),
              modifier = Modifier.size(40.dp)
            ) {
              Icon(
                Icons.Default.CreditCard,
                contentDescription = null,
                tint = Color(0xFF7C3AED),
                modifier = Modifier.padding(10.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "الدفع بالعملات الأجنبية (الأورو والدينار التونسي)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF7C3AED)
              )
              Text(
                text = "ميزة خاصة لزبائننا لتسديد الخدمات والطلبات",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "• الدفع بالأورو (€ Euro): متاح عبر حساب Paysera / Wise أو نقداً بالمكتبة.",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = "• الدفع بالدينار التونسي (TND): متاح تسديد الطلبات والدورات والبحوث نقداً بحي 113.",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = "• يتم حساب سعر الصرف اللحظي وفق تسعيرة السوق الرسمية بالمكتبة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun AccountCard(
  title: String,
  identifierLabel: String,
  identifierValue: String,
  accountHolder: String,
  icon: ImageVector,
  badgeColor: Color,
  notes: String,
  onCopy: () -> Unit
) {
  ElevatedCard(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = CircleShape,
            color = badgeColor.copy(alpha = 0.15f),
            modifier = Modifier.size(38.dp)
          ) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = badgeColor,
              modifier = Modifier.padding(9.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = badgeColor
          )
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = badgeColor.copy(alpha = 0.12f)
        ) {
          Text(
            text = "معتمد",
            color = badgeColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Column {
        Text(identifierLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onCopy() }
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = identifierValue,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = badgeColor, modifier = Modifier.size(18.dp))
          }
        }
      }

      Text(
        text = "صاحب الحساب: $accountHolder",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 11.sp
      )

      Text(
        text = notes,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 11.sp
      )
    }
  }
}

data class TelecomItem(
  val name: String,
  val desc: String,
  val brandColor: Color,
  val icon: ImageVector
)

private fun copyToClipboard(context: Context, text: String, label: String) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val clip = ClipData.newPlainText(label, text)
  clipboard.setPrimaryClip(clip)
  Toast.makeText(context, "تم نسخ $label إلى الحافظة", Toast.LENGTH_SHORT).show()
}
