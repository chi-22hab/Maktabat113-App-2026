package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0F4C81)
val NavyDark = Color(0xFF0A3357)
val NavyLight = Color(0xFF2563EB)
val NavyContainer = Color(0xFFE0F2FE)
val OnNavyContainer = Color(0xFF0C4A6E)

val AmberGold = Color(0xFFD97706)
val AmberLight = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF78350F)

val EmeraldGreen = Color(0xFF059669)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF064E3B)

val SlateDark = Color(0xFF0F172A)
val SlateMedium = Color(0xFF334155)
val SlateLight = Color(0xFF64748B)
val SlateBorder = Color(0xFFE2E8F0)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)

// Dark Theme Colors
val NavyPrimaryDark = Color(0xFF60A5FA)
val NavyContainerDark = Color(0xFF1E3A5F)
val AmberGoldDark = Color(0xFFFBBF24)
val EmeraldGreenDark = Color(0xFF34D399)
val BackgroundDark = Color(0xFF0B132B)
val SurfaceDark = Color(0xFF1C2541)
val SurfaceCardDark = Color(0xFF253252)
