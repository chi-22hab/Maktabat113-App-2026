package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = NavyPrimaryDark,
  onPrimary = Color(0xFF002F65),
  primaryContainer = NavyContainerDark,
  onPrimaryContainer = Color(0xFFD6E4FF),
  secondary = AmberGoldDark,
  onSecondary = Color(0xFF452B00),
  secondaryContainer = Color(0xFF633F00),
  onSecondaryContainer = Color(0xFFFFDDB3),
  tertiary = EmeraldGreenDark,
  onTertiary = Color(0xFF003822),
  tertiaryContainer = Color(0xFF005234),
  onTertiaryContainer = Color(0xFF8CF5BE),
  background = BackgroundDark,
  onBackground = Color(0xFFE2E8F0),
  surface = SurfaceDark,
  onSurface = Color(0xFFE2E8F0),
  surfaceVariant = SurfaceCardDark,
  onSurfaceVariant = Color(0xFFCBD5E1)
)

private val LightColorScheme = lightColorScheme(
  primary = NavyPrimary,
  onPrimary = Color.White,
  primaryContainer = NavyContainer,
  onPrimaryContainer = OnNavyContainer,
  secondary = AmberGold,
  onSecondary = Color.White,
  secondaryContainer = AmberContainer,
  onSecondaryContainer = OnAmberContainer,
  tertiary = EmeraldGreen,
  onTertiary = Color.White,
  tertiaryContainer = EmeraldContainer,
  onTertiaryContainer = OnEmeraldContainer,
  background = BackgroundLight,
  onBackground = SlateDark,
  surface = SurfaceCard,
  onSurface = SlateDark,
  surfaceVariant = Color(0xFFF1F5F9),
  onSurfaceVariant = SlateMedium,
  outline = SlateBorder
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep distinctive brand navy & gold colors
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
