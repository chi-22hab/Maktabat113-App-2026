package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.EducationalResource
import com.example.data.model.FlexyOrder
import com.example.data.model.JobAnnouncement
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ServiceRequest
import com.example.data.repository.MaktabatRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class CartItem(
  val product: Product,
  val quantity: Int = 1
)

data class ChatMessage(
  val id: Long = System.currentTimeMillis(),
  val sender: MessageSender,
  val text: String,
  val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
  USER, AI, SYSTEM
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: MaktabatRepository

  init {
    val db = AppDatabase.getDatabase(application, viewModelScope)
    repository = MaktabatRepository(db)
  }

  // Admin / Owner Mode
  private val _isAdminMode = MutableStateFlow(false)
  val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

  fun toggleAdminMode(enabled: Boolean) {
    _isAdminMode.value = enabled
  }

  // Toast / User alerts
  private val _snackbarMessage = MutableSharedFlow<String>()
  val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

  fun showMessage(msg: String) {
    viewModelScope.launch {
      _snackbarMessage.emit(msg)
    }
  }

  // --- Products & Store ---
  private val _selectedProductCategory = MutableStateFlow(ProductCategory.ALL.titleAr)
  val selectedProductCategory: StateFlow<String> = _selectedProductCategory.asStateFlow()

  private val _productSearchQuery = MutableStateFlow("")
  val productSearchQuery: StateFlow<String> = _productSearchQuery.asStateFlow()

  val productsList: StateFlow<List<Product>> = combine(
    repository.allProducts,
    _selectedProductCategory,
    _productSearchQuery
  ) { list, category, query ->
    list.filter { product ->
      val matchesCategory = (category == ProductCategory.ALL.titleAr || product.category == category)
      val matchesQuery = query.isBlank() || product.name.contains(query, ignoreCase = true) || product.description.contains(query, ignoreCase = true)
      matchesCategory && matchesQuery
    }
  }.let { flow ->
    val state = MutableStateFlow<List<Product>>(emptyList())
    viewModelScope.launch {
      flow.collect { state.value = it }
    }
    state.asStateFlow()
  }

  fun setProductCategory(category: String) {
    _selectedProductCategory.value = category
  }

  fun setProductSearchQuery(query: String) {
    _productSearchQuery.value = query
  }

  // Editable price for any product (requested specifically by user)
  fun updateProductPrice(productId: Long, newPrice: Double) {
    viewModelScope.launch {
      repository.updateProductPrice(productId, newPrice)
      showMessage("تم تحديث سعر المنتج بنجاح: ${newPrice.toInt()} دج")
    }
  }

  fun addNewProduct(name: String, category: String, price: Double, desc: String, imageUrl: String = "") {
    viewModelScope.launch {
      val product = Product(
        name = name,
        category = category,
        priceDzd = price,
        description = desc,
        imageUrl = imageUrl,
        inStock = true
      )
      repository.insertProduct(product)
      showMessage("تمت إضافة المنتج الجديد إلى رفوف المكتبة!")
    }
  }

  fun deleteProduct(product: Product) {
    viewModelScope.launch {
      repository.deleteProduct(product)
      removeFromCart(product.id)
      showMessage("تم حذف المنتج من قائمة المعروضات.")
    }
  }

  // --- Cart ---
  private val _cart = MutableStateFlow<Map<Long, CartItem>>(emptyMap())
  val cart: StateFlow<Map<Long, CartItem>> = _cart.asStateFlow()

  fun addToCart(product: Product) {
    val current = _cart.value.toMutableMap()
    val existing = current[product.id]
    if (existing != null) {
      current[product.id] = existing.copy(quantity = existing.quantity + 1)
    } else {
      current[product.id] = CartItem(product, 1)
    }
    _cart.value = current
    showMessage("تمت إضافة \"${product.name}\" إلى السلة")
  }

  fun updateCartQuantity(productId: Long, quantity: Int) {
    val current = _cart.value.toMutableMap()
    if (quantity <= 0) {
      current.remove(productId)
    } else {
      val item = current[productId]
      if (item != null) {
        current[productId] = item.copy(quantity = quantity)
      }
    }
    _cart.value = current
  }

  fun removeFromCart(productId: Long) {
    val current = _cart.value.toMutableMap()
    current.remove(productId)
    _cart.value = current
  }

  fun clearCart() {
    _cart.value = emptyMap()
  }

  val cartTotalPrice: Double
    get() = _cart.value.values.sumOf { it.product.priceDzd * it.quantity }

  // --- Job Announcements ---
  private val _jobFilterSector = MutableStateFlow("الكل")
  val jobFilterSector: StateFlow<String> = _jobFilterSector.asStateFlow()

  val jobAnnouncements: StateFlow<List<JobAnnouncement>> = combine(
    repository.allJobAnnouncements,
    _jobFilterSector
  ) { list, sector ->
    if (sector == "الكل") list else list.filter { it.sector == sector }
  }.let { flow ->
    val state = MutableStateFlow<List<JobAnnouncement>>(emptyList())
    viewModelScope.launch {
      flow.collect { state.value = it }
    }
    state.asStateFlow()
  }

  fun setJobFilterSector(sector: String) {
    _jobFilterSector.value = sector
  }

  fun addNewJobAnnouncement(
    title: String,
    employer: String,
    sector: String,
    deadline: String,
    description: String,
    conditions: String,
    requiredFiles: String,
    imageUrl: String = "",
    isUrgent: Boolean = false
  ) {
    viewModelScope.launch {
      val job = JobAnnouncement(
        title = title,
        employer = employer,
        sector = sector,
        datePosted = "اليوم",
        deadline = deadline,
        description = description,
        conditions = conditions,
        requiredFiles = requiredFiles,
        imageUrl = imageUrl,
        isUrgent = isUrgent
      )
      repository.insertJobAnnouncement(job)
      showMessage("تم نشر إعلان التوظيف للعامة بنجاح!")
    }
  }

  fun deleteJobAnnouncement(job: JobAnnouncement) {
    viewModelScope.launch {
      repository.deleteJobAnnouncement(job)
      showMessage("تم حذف إعلان التوظيف.")
    }
  }

  // --- Educational Resources (Lessons, Videos, PDFs) ---
  private val _selectedAcademicLevel = MutableStateFlow("جميع المستويات")
  val selectedAcademicLevel: StateFlow<String> = _selectedAcademicLevel.asStateFlow()

  private val _selectedResourceType = MutableStateFlow("الكل")
  val selectedResourceType: StateFlow<String> = _selectedResourceType.asStateFlow()

  val educationalResources: StateFlow<List<EducationalResource>> = combine(
    repository.allEducationalResources,
    _selectedAcademicLevel,
    _selectedResourceType
  ) { list, level, type ->
    list.filter { item ->
      val matchesLevel = (level == "جميع المستويات" || item.academicLevel == level || level.contains(item.academicLevel))
      val matchesType = (type == "الكل" || item.resourceType == type)
      matchesLevel && matchesType
    }
  }.let { flow ->
    val state = MutableStateFlow<List<EducationalResource>>(emptyList())
    viewModelScope.launch {
      flow.collect { state.value = it }
    }
    state.asStateFlow()
  }

  fun setSelectedAcademicLevel(level: String) {
    _selectedAcademicLevel.value = level
  }

  fun setSelectedResourceType(type: String) {
    _selectedResourceType.value = type
  }

  fun addNewEducationalResource(
    title: String,
    academicLevel: String,
    subject: String,
    resourceType: String,
    description: String,
    fileOrVideoUrl: String,
    fileSizeOrDuration: String = ""
  ) {
    viewModelScope.launch {
      val item = EducationalResource(
        title = title,
        academicLevel = academicLevel,
        subject = subject,
        resourceType = resourceType,
        description = description,
        fileOrVideoUrl = fileOrVideoUrl,
        fileSizeOrDuration = fileSizeOrDuration,
        dateAdded = "اليوم"
      )
      repository.insertEducationalResource(item)
      showMessage("تمت إضافة المحتوى التعليمي بنجاح إلى المنصة!")
    }
  }

  fun deleteEducationalResource(resource: EducationalResource) {
    viewModelScope.launch {
      repository.deleteEducationalResource(resource)
      showMessage("تم حذف المحتوى التعليمي.")
    }
  }

  // --- Service Requests (Printing, Typing, Registrations) ---
  val serviceRequests: StateFlow<List<ServiceRequest>> = repository.allServiceRequests.let { flow ->
    val state = MutableStateFlow<List<ServiceRequest>>(emptyList())
    viewModelScope.launch {
      flow.collect { state.value = it }
    }
    state.asStateFlow()
  }

  fun submitServiceRequest(
    serviceCategory: String,
    serviceTitle: String,
    customerName: String,
    customerPhone: String,
    details: String,
    options: String,
    estimatedPriceDzd: Double
  ) {
    viewModelScope.launch {
      val req = ServiceRequest(
        serviceCategory = serviceCategory,
        serviceTitle = serviceTitle,
        customerName = customerName,
        customerPhone = customerPhone,
        details = details,
        options = options,
        estimatedPriceDzd = estimatedPriceDzd
      )
      repository.submitServiceRequest(req)
      showMessage("تم إرسال طلبك بنجاح! سيتصل بك فريق مكتبة 113 لتأكيد الاستلام.")
    }
  }

  // --- Flexy & Bill Payments ---
  val flexyOrders: StateFlow<List<FlexyOrder>> = repository.allFlexyOrders.let { flow ->
    val state = MutableStateFlow<List<FlexyOrder>>(emptyList())
    viewModelScope.launch {
      flow.collect { state.value = it }
    }
    state.asStateFlow()
  }

  fun submitFlexyOrder(
    serviceName: String,
    targetIdentifier: String,
    amount: Double,
    currency: String,
    paymentMethod: String,
    senderPhone: String,
    transactionReference: String = ""
  ) {
    viewModelScope.launch {
      val order = FlexyOrder(
        serviceName = serviceName,
        targetIdentifier = targetIdentifier,
        amount = amount,
        currency = currency,
        paymentMethod = paymentMethod,
        senderPhone = senderPhone,
        transactionReference = transactionReference
      )
      repository.submitFlexyOrder(order)
      showMessage("تم تسجيل طلب الشحن/الدفع بنجاح! سيتم التنفيذ فور التحقق.")
    }
  }

  // --- AI Assistant Chat ---
  private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
    listOf(
      ChatMessage(
        sender = MessageSender.AI,
        text = "مرحباً بك في المستشار الذكي لمكتبة 113! 🎓\nأنا مساعدك الشخصي لمساعدتك في:\n• شرح وتبسيط الدروس والمسائل\n• مقترحات عناوين وخطط مذكرات التخرج والبحوث الجامعية\n• توجيهات مسابقات التوظيف لقطاع التربية والإدارة\n• معلومات تسجيلات البكالوريا (BAC)، البيام (BEM)، وسكنات عدل AADL.\nكيف يمكنني مساعدتك اليوم؟"
      )
    )
  )
  val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

  private val _isAiLoading = MutableStateFlow(false)
  val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

  fun sendAiPrompt(prompt: String) {
    if (prompt.isBlank()) return

    val userMsg = ChatMessage(sender = MessageSender.USER, text = prompt)
    _chatMessages.value = _chatMessages.value + userMsg
    _isAiLoading.value = true

    viewModelScope.launch {
      val result = repository.askAi(prompt)
      val reply = result.getOrElse { "عذراً، حدث خطأ أثناء الاتصال بمساعد الذكاء الاصطناعي." }
      val aiMsg = ChatMessage(sender = MessageSender.AI, text = reply)
      _chatMessages.value = _chatMessages.value + aiMsg
      _isAiLoading.value = false
    }
  }

  fun clearAiChat() {
    _chatMessages.value = listOf(
      ChatMessage(
        sender = MessageSender.AI,
        text = "تمت إعادة ضبط المحادثة. تفضل بطرح أي سؤال أو استشارة دراسية أو إدارية!"
      )
    )
  }
}
