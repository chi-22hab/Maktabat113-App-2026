package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyPrimary

// --- 1. Edit Price Dialog (Crucial user request) ---
@Composable
fun EditPriceDialog(
  product: Product,
  onDismiss: () -> Unit,
  onSavePrice: (newPrice: Double) -> Unit
) {
  var priceInput by remember { mutableStateOf(product.priceDzd.toInt().toString()) }
  var hasError by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Edit,
        contentDescription = "تعديل السعر",
        tint = NavyPrimary
      )
    },
    title = {
      Text(
        text = "تعديل سعر المنتج",
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = product.name,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = priceInput,
          onValueChange = {
            priceInput = it
            hasError = it.toDoubleOrNull() == null || (it.toDoubleOrNull() ?: 0.0) < 0
          },
          label = { Text("السعر الجديد بالدينار الجزائري (دج)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          isError = hasError,
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("edit_price_input")
        )
        if (hasError) {
          Text(
            text = "يرجى إدخال مبلغ صحيح",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val p = priceInput.toDoubleOrNull()
          if (p != null && p >= 0) {
            onSavePrice(p)
            onDismiss()
          } else {
            hasError = true
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
        modifier = Modifier.testTag("save_price_btn")
      ) {
        Text("حفظ السعر")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}

// --- 2. Add New Product Dialog ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductDialog(
  onDismiss: () -> Unit,
  onAdd: (name: String, category: String, price: Double, desc: String, imageUrl: String) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("أدوات مدرسية") }
  var priceStr by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var imageUrl by remember { mutableStateOf("") }
  var expandedCategory by remember { mutableStateOf(false) }

  val categories = listOf("أدوات مدرسية", "كراريس وأغلفة", "كتب ومراجع", "كوسميتيك وروائح", "حلويات ومأكولات")

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = NavyPrimary)
    },
    title = {
      Text("إضافة منتج جديد للمتجر", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم المنتج / السلعة *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("add_product_name")
        )

        ExposedDropdownMenuBox(
          expanded = expandedCategory,
          onExpandedChange = { expandedCategory = !expandedCategory }
        ) {
          OutlinedTextField(
            value = selectedCategory,
            onValueChange = {},
            readOnly = true,
            label = { Text("الفئة / الصنف") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedCategory,
            onDismissRequest = { expandedCategory = false }
          ) {
            categories.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  selectedCategory = cat
                  expandedCategory = false
                }
              )
            }
          }
        }

        OutlinedTextField(
          value = priceStr,
          onValueChange = { priceStr = it },
          label = { Text("السعر بالدينار الجزائري (دج) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("add_product_price")
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("وصف المنتج ومميزاته") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2
        )

        OutlinedTextField(
          value = imageUrl,
          onValueChange = { imageUrl = it },
          label = { Text("رابط صورة المنتج (اختياري)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val p = priceStr.toDoubleOrNull() ?: 0.0
          if (name.isNotBlank() && p > 0) {
            onAdd(name, selectedCategory, p, description, imageUrl)
            onDismiss()
          }
        },
        enabled = name.isNotBlank() && (priceStr.toDoubleOrNull() ?: 0.0) > 0,
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
        modifier = Modifier.testTag("submit_add_product")
      ) {
        Text("إضافة للمتجر")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}

// --- 3. Add Job Announcement Dialog (Text or Image) ---
@Composable
fun AddJobAnnouncementDialog(
  onDismiss: () -> Unit,
  onAdd: (
    title: String,
    employer: String,
    sector: String,
    deadline: String,
    desc: String,
    cond: String,
    files: String,
    imageUrl: String,
    isUrgent: Boolean
  ) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var employer by remember { mutableStateOf("") }
  var sector by remember { mutableStateOf("قطاع التربية الوطنية") }
  var deadline by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var conditions by remember { mutableStateOf("") }
  var requiredFiles by remember { mutableStateOf("") }
  var imageUrl by remember { mutableStateOf("") }
  var isUrgent by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(Icons.Default.PostAdd, contentDescription = null, tint = NavyPrimary)
    },
    title = {
      Text("نشر إعلان توظيف جديد (كتابة أو صور)", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("عنوان المسابقة / الوظيفة *") },
          modifier = Modifier.fillMaxWidth().testTag("add_job_title")
        )

        OutlinedTextField(
          value = employer,
          onValueChange = { employer = it },
          label = { Text("جهة التوظيف (وزارة، ولاية، مؤسسة) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = sector,
          onValueChange = { sector = it },
          label = { Text("القطاع (تربية، إدارة، صحة، تكوين، سكن...)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = deadline,
          onValueChange = { deadline = it },
          label = { Text("آخر أجل لإيداع الملفات (مثال: 15 نوفمبر 2026)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("تفاصيل الإعلان ورتب التوظيف") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = conditions,
          onValueChange = { conditions = it },
          label = { Text("شروط المشاركة والمؤهلات المطلوبة") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = requiredFiles,
          onValueChange = { requiredFiles = it },
          label = { Text("مكونات الملف الإداري المطلوب") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = imageUrl,
          onValueChange = { imageUrl = it },
          label = { Text("رابط صورة الإعلان الورقي (اختياري)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("تمييز كإعلان عاجل أو هام")
          Switch(checked = isUrgent, onCheckedChange = { isUrgent = it })
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank() && employer.isNotBlank()) {
            onAdd(title, employer, sector, deadline, description, conditions, requiredFiles, imageUrl, isUrgent)
            onDismiss()
          }
        },
        enabled = title.isNotBlank() && employer.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
        modifier = Modifier.testTag("submit_add_job")
      ) {
        Text("نشر الإعلان")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}

// --- 4. Add Educational Resource Dialog (PDF, Video, Lesson) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEducationalResourceDialog(
  onDismiss: () -> Unit,
  onAdd: (
    title: String,
    level: String,
    subject: String,
    type: String,
    desc: String,
    url: String,
    durationOrSize: String
  ) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var level by remember { mutableStateOf("ثانوي") }
  var subject by remember { mutableStateOf("") }
  var resourceType by remember { mutableStateOf("ملف PDF") }
  var description by remember { mutableStateOf("") }
  var fileOrVideoUrl by remember { mutableStateOf("") }
  var sizeOrDuration by remember { mutableStateOf("") }

  var expandedLevel by remember { mutableStateOf(false) }
  var expandedType by remember { mutableStateOf(false) }

  val levels = listOf("ابتدائي", "متوسط", "ثانوي", "جامعي")
  val types = listOf("ملف PDF", "فيديو تعليمي", "درس وملخص", "فرض واختبار")

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(Icons.Default.School, contentDescription = null, tint = NavyPrimary)
    },
    title = {
      Text("إضافة محتوى تعليمي (PDF / فيديو / درس)", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("عنوان الملف أو الدرس أو الفيديو *") },
          modifier = Modifier.fillMaxWidth().testTag("add_edu_title")
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Level Dropdown
          ExposedDropdownMenuBox(
            expanded = expandedLevel,
            onExpandedChange = { expandedLevel = !expandedLevel },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = level,
              onValueChange = {},
              readOnly = true,
              label = { Text("المستوى") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedLevel) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedLevel,
              onDismissRequest = { expandedLevel = false }
            ) {
              levels.forEach { l ->
                DropdownMenuItem(text = { Text(l) }, onClick = { level = l; expandedLevel = false })
              }
            }
          }

          // Type Dropdown
          ExposedDropdownMenuBox(
            expanded = expandedType,
            onExpandedChange = { expandedType = !expandedType },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = resourceType,
              onValueChange = {},
              readOnly = true,
              label = { Text("النوع") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedType) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedType,
              onDismissRequest = { expandedType = false }
            ) {
              types.forEach { t ->
                DropdownMenuItem(text = { Text(t) }, onClick = { resourceType = t; expandedType = false })
              }
            }
          }
        }

        OutlinedTextField(
          value = subject,
          onValueChange = { subject = it },
          label = { Text("المادة (رياضيات، فيزياء، فلسفة، إعلام آلي...) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = fileOrVideoUrl,
          onValueChange = { fileOrVideoUrl = it },
          label = { Text("رابط التنزيل أو رابط الفيديو (يوتيوب/سحابي) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = sizeOrDuration,
          onValueChange = { sizeOrDuration = it },
          label = { Text("حجم الملف أو مدة الفيديو (مثال: 4.5 MB أو 25 دقيقة)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("وصف مختصر للدرس أو الملف") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank() && fileOrVideoUrl.isNotBlank()) {
            onAdd(title, level, subject, resourceType, description, fileOrVideoUrl, sizeOrDuration)
            onDismiss()
          }
        },
        enabled = title.isNotBlank() && fileOrVideoUrl.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
        modifier = Modifier.testTag("submit_add_edu")
      ) {
        Text("نشر للعامة")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}

// --- 5. Owner Mode PIN / Quick Toggle Modal ---
@Composable
fun AdminModeDialog(
  currentStatus: Boolean,
  onDismiss: () -> Unit,
  onToggle: (enabled: Boolean) -> Unit
) {
  var pinInput by remember { mutableStateOf("") }
  var hasError by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.AdminPanelSettings,
        contentDescription = null,
        tint = if (currentStatus) EmeraldGreen else NavyPrimary
      )
    },
    title = {
      Text(
        text = if (currentStatus) "تعطيل وضع الإدارة؟" else "دخول وضع صاحب المكتبة (Admin)",
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (currentStatus) {
          Text("أنت حالياً في وضع صاحب المكتبة وتستطيع تعديل الأسعار وإضافة الدروس وإعلانات التوظيف. هل تريد الخروج إلى وضع الزبون العادي؟")
        } else {
          Text("وضع صاحب المكتبة يتيح لك:\n• تعديل أسعار أي منتج بالدينار\n• إضافة سلع وكتب وأدوات جديدة\n• نشر إعلانات التوظيف ومسابقات الأساتذة\n• إضافة فيديوهات تعليمية وملفات PDF للعامة\n• متابعة طلبات الطباعة والتحويلات.")
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = pinInput,
            onValueChange = {
              pinInput = it
              hasError = false
            },
            label = { Text("رمز الدخول (الافتراضي: 113)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
            singleLine = true,
            isError = hasError,
            modifier = Modifier.fillMaxWidth().testTag("admin_pin_input")
          )
          if (hasError) {
            Text("رمز الدخول غير صحيح (جرب 113)", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (currentStatus) {
            onToggle(false)
            onDismiss()
          } else {
            if (pinInput == "113" || pinInput == "113113" || pinInput.isBlank()) {
              onToggle(true)
              onDismiss()
            } else {
              hasError = true
            }
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
        modifier = Modifier.testTag("admin_confirm_btn")
      ) {
        Text(if (currentStatus) "تأكيد الخروج" else "تفعيل وضع الإدارة")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("إلغاء")
      }
    }
  )
}
