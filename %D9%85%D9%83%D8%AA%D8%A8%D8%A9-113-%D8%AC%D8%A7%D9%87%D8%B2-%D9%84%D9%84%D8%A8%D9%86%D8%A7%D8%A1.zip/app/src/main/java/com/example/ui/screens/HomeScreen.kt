package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.JobAnnouncement
import com.example.ui.components.AdminModeDialog
import com.example.ui.components.ContactHeader
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.OnNavyContainer
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
  viewModel: MainViewModel,
  onNavigateToTab: (Int) -> Unit,
  modifier: Modifier = Modifier
) {
  val isAdminMode by viewModel.isAdminMode.collectAsState()
  val jobAds by viewModel.jobAnnouncements.collectAsState()
  val educationalFiles by viewModel.educationalResources.collectAsState()

  var showAdminDialog by remember { mutableStateOf(false) }

  if (showAdminDialog) {
    AdminModeDialog(
      currentStatus = isAdminMode,
      onDismiss = { showAdminDialog = false },
      onToggle = { enabled ->
        viewModel.toggleAdminMode(enabled)
        viewModel.showMessage(
          if (enabled) "تم تفعيل وضع صاحب المكتبة! يمكنك الآن تعديل الأسعار وإضافة محتوى."
          else "تم الخروج من وضع صاحب المكتبة."
        )
      }
    )
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Hero Storefront Banner
    item {
      HeroBannerCard(
        isAdminMode = isAdminMode,
        onToggleAdmin = { showAdminDialog = true }
      )
    }

    // 2. Contact Header: حي 113, Phone 0664751271, Email mactabat113@gmail.com
    item {
      ContactHeader()
    }

    // 3. Admin Mode Alert Bar if active
    item {
      AnimatedVisibility(visible = isAdminMode) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { showAdminDialog = true },
          colors = CardDefaults.cardColors(
            containerColor = AmberGold.copy(alpha = 0.15f)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = null,
                tint = AmberGold
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "وضع صاحب المكتبة نشط (Admin Mode)",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = AmberGold
                )
                Text(
                  text = "يمكنك تعديل أسعار السلع، نشر إعلانات التوظيف، وإضافة دروس وPDFs",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  fontSize = 11.sp
                )
              }
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = AmberGold
            ) {
              Text(
                text = "إيقاف",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }
      }
    }

    // 4. Quick Services Grid
    item {
      Text(
        text = "خدمات مكتبة 113 الشاملة",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        ServiceQuickCard(
          modifier = Modifier.weight(1f),
          title = "الطباعة والبحوث",
          subtitle = "مذكرات وفروض",
          icon = Icons.Default.Print,
          accentColor = NavyPrimary,
          onClick = { onNavigateToTab(1) } // Services
        )
        ServiceQuickCard(
          modifier = Modifier.weight(1f),
          title = "المتجر والسلع",
          subtitle = "أدوات، كتب، عطور",
          icon = Icons.Default.ShoppingCart,
          accentColor = AmberGold,
          onClick = { onNavigateToTab(2) } // Store
        )
      }
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        ServiceQuickCard(
          modifier = Modifier.weight(1f),
          title = "إعلانات التوظيف",
          subtitle = "مسابقات الأساتذة والإدارة",
          icon = Icons.Default.Work,
          accentColor = EmeraldGreen,
          onClick = { onNavigateToTab(3) } // Jobs & Edu
        )
        ServiceQuickCard(
          modifier = Modifier.weight(1f),
          title = "فليكسي وفواتير",
          subtitle = "جيزي، موبيليس، إيدوم",
          icon = Icons.Default.ElectricBolt,
          accentColor = Color(0xFF7C3AED),
          onClick = { onNavigateToTab(4) } // Flexy
        )
      }
      Spacer(modifier = Modifier.height(10.dp))
      // AI Assistant Special Callout Card
      AiSpecialBannerCard(onClick = { onNavigateToTab(5) })
    }

    // 5. Latest Job Contests & Announcements
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "أحدث إعلانات التوظيف والمسابقات",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        TextButton(
          onClick = { onNavigateToTab(3) }
        ) {
          Text("عرض الكل", color = NavyPrimary)
        }
      }
    }

    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(jobAds.take(4)) { job ->
          JobSummaryCard(job = job, onClick = { onNavigateToTab(3) })
        }
      }
    }

    // 6. Educational Corner (Videos & Free PDFs)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "بنك الدروس والـ PDF والفيديوهات",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        TextButton(
          onClick = { onNavigateToTab(3) }
        ) {
          Text("تصفح المكتبة", color = NavyPrimary)
        }
      }
    }

    items(educationalFiles.take(3)) { resource ->
      ResourceSummaryCard(resource = resource, onOpen = { onNavigateToTab(3) })
    }

    // 7. Footer note
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "مكتبة 113 - حي 113 • chi-22hab/Maktabat113",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = OnNavyContainer
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "طباعة مستندات • استخراج بحوث وفروض • كتابة مذكرات • أدوات مدرسية ومواد كوسميتيك • فليكسي وتسديد فواتير • تسجيلات جامعية ومسابقات",
            style = MaterialTheme.typography.bodySmall,
            color = OnNavyContainer.copy(alpha = 0.8f),
            textAlign = TextAlign.Center,
            fontSize = 11.sp
          )
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
fun HeroBannerCard(
  isAdminMode: Boolean,
  onToggleAdmin: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .height(180.dp),
    shape = RoundedCornerShape(20.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Background Image
      Image(
        painter = painterResource(id = R.drawable.banner_maktabat_113),
        contentDescription = "مكتبة 113",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )

      // Gradient overlay for legibility
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Transparent,
                Color.Black.copy(alpha = 0.85f)
              ),
              startY = 40f
            )
          )
      )

      // Top Admin badge toggle button
      Surface(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(12.dp)
          .clip(CircleShape)
          .clickable { onToggleAdmin() },
        color = if (isAdminMode) AmberGold else Color.Black.copy(alpha = 0.5f),
        shape = CircleShape
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = "وضع المدير",
            tint = Color.White,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isAdminMode) "وضع الإدارة" else "المدير",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // Bottom Content
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(16.dp)
      ) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = AmberGold
        ) {
          Text(
            text = "حي 113 • خدمات رقمية ومدرسية",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "مكتبة 113 (Maktabat 113)",
          style = MaterialTheme.typography.titleLarge,
          color = Color.White,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "وجهتك الأولى لطباعة البحوث، الأدوات المدرسية، والتسجيلات الرسمية",
          style = MaterialTheme.typography.bodySmall,
          color = Color.White.copy(alpha = 0.9f),
          fontSize = 12.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
fun ServiceQuickCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ElevatedCard(
    modifier = modifier
      .clip(RoundedCornerShape(16.dp))
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = accentColor.copy(alpha = 0.12f),
        modifier = Modifier.size(42.dp)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.padding(10.dp)
        )
      }
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 11.sp,
        maxLines = 1
      )
    }
  }
}

@Composable
fun AiSpecialBannerCard(
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = NavyPrimary
    )
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = AmberGold,
        modifier = Modifier.size(48.dp)
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = "الذكاء الاصطناعي",
          tint = Color.White,
          modifier = Modifier.padding(12.dp)
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "المستشار الذكي للطلبة والزبائن",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = Color.White.copy(alpha = 0.2f)
          ) {
            Text(
              text = "Gemini AI",
              color = Color.White,
              fontSize = 9.sp,
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
          }
        }
        Text(
          text = "مساعدتك في شرح الدروس، خطط المذكرات، واستشارات التوظيف والتسجيلات",
          style = MaterialTheme.typography.bodySmall,
          color = Color.White.copy(alpha = 0.85f),
          fontSize = 11.sp
        )
      }
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.White
      ) {
        Text(
          text = "اسأل الآن",
          color = NavyPrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
      }
    }
  }
}

@Composable
fun JobSummaryCard(
  job: JobAnnouncement,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(260.dp)
      .clip(RoundedCornerShape(14.dp))
      .clickable { onClick() },
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = EmeraldGreen.copy(alpha = 0.15f)
        ) {
          Text(
            text = job.sector,
            color = EmeraldGreen,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
        if (job.isUrgent) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
          ) {
            Text(
              text = "عاجل",
              color = MaterialTheme.colorScheme.error,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = job.title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "الجهة: ${job.employer}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 11.sp
      )
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "آخر أجل: ${job.deadline}",
          style = MaterialTheme.typography.labelSmall,
          color = AmberGold,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}

@Composable
fun ResourceSummaryCard(
  resource: com.example.data.model.EducationalResource,
  onOpen: () -> Unit
) {
  ElevatedCard(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable { onOpen() },
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (resource.resourceType == "فيديو تعليمي") Color(0xFFEF4444).copy(alpha = 0.12f)
        else NavyPrimary.copy(alpha = 0.12f),
        modifier = Modifier.size(44.dp)
      ) {
        Icon(
          imageVector = if (resource.resourceType == "فيديو تعليمي") Icons.Default.VideoLibrary else Icons.Default.MenuBook,
          contentDescription = null,
          tint = if (resource.resourceType == "فيديو تعليمي") Color(0xFFEF4444) else NavyPrimary,
          modifier = Modifier.padding(10.dp)
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = AmberGold.copy(alpha = 0.12f)
          ) {
            Text(
              text = resource.academicLevel,
              color = AmberGold,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = resource.subject,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = resource.title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = resource.fileSizeOrDuration,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 11.sp
        )
      }
    }
  }
}
