package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AcademicLevel
import com.example.data.model.EducationalResource
import com.example.data.model.JobAnnouncement
import com.example.ui.components.AddEducationalResourceDialog
import com.example.ui.components.AddJobAnnouncementDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.OnNavyContainer
import com.example.ui.viewmodel.MainViewModel

@Composable
fun JobsEduScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: إعلانات التوظيف, 1: الدروس والفيديوهات والملفات
  val isAdminMode by viewModel.isAdminMode.collectAsState()

  var showAddJobDialog by remember { mutableStateOf(false) }
  var showAddEduDialog by remember { mutableStateOf(false) }

  if (showAddJobDialog) {
    AddJobAnnouncementDialog(
      onDismiss = { showAddJobDialog = false },
      onAdd = { title, emp, sector, deadline, desc, cond, files, img, urgent ->
        viewModel.addNewJobAnnouncement(title, emp, sector, deadline, desc, cond, files, img, urgent)
      }
    )
  }

  if (showAddEduDialog) {
    AddEducationalResourceDialog(
      onDismiss = { showAddEduDialog = false },
      onAdd = { title, level, subj, type, desc, url, duration ->
        viewModel.addNewEducationalResource(title, level, subj, type, desc, url, duration)
      }
    )
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      if (isAdminMode) {
        FloatingActionButton(
          onClick = {
            if (selectedTab == 0) showAddJobDialog = true else showAddEduDialog = true
          },
          containerColor = AmberGold,
          contentColor = Color.White,
          modifier = Modifier.testTag("admin_add_job_or_edu_fab")
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = if (selectedTab == 0) "إضافة إعلان توظيف" else "إضافة ملف/فيديو تعليمي"
          )
        }
      }
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
    ) {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = NavyPrimary
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("إعلانات التوظيف والمسابقات", fontWeight = FontWeight.Bold) },
          icon = { Icon(Icons.Default.Work, contentDescription = null) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("الدروس والفيديوهات و PDF", fontWeight = FontWeight.Bold) },
          icon = { Icon(Icons.Default.School, contentDescription = null) }
        )
      }

      when (selectedTab) {
        0 -> JobAnnouncementsSubScreen(viewModel, isAdminMode, onOpenAdd = { showAddJobDialog = true })
        1 -> EducationalResourcesSubScreen(viewModel, isAdminMode, onOpenAdd = { showAddEduDialog = true })
      }
    }
  }
}

// --- Sub-Screen 1: إعلانات ومسابقات التوظيف ---
@Composable
fun JobAnnouncementsSubScreen(
  viewModel: MainViewModel,
  isAdmin: Boolean,
  onOpenAdd: () -> Unit
) {
  val jobAds by viewModel.jobAnnouncements.collectAsState()
  val filterSector by viewModel.jobFilterSector.collectAsState()
  val context = LocalContext.current

  val sectors = listOf("الكل", "قطاع التربية الوطنية", "الإدارة العمومية", "التكوين المهني", "سكن عدل وغيرها")

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    if (isAdmin) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = AmberGold.copy(alpha = 0.12f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "خانة خاصة بصاحب المكتبة لنشر الإعلانات",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = AmberGold
              )
              Text(
                text = "يمكنك إضافة إعلانات توظيف جديدة بالكتابة أو الصور وتحديد الشروط والآجال.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
              )
            }
            Button(
              onClick = onOpenAdd,
              colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("إضافة", fontSize = 11.sp)
            }
          }
        }
      }
    }

    // Sector Filter Chips
    item {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(sectors) { sector ->
          val isSelected = filterSector == sector
          FilterChip(
            selected = isSelected,
            onClick = { viewModel.setJobFilterSector(sector) },
            label = { Text(sector) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NavyPrimary,
              selectedLabelColor = Color.White
            )
          )
        }
      }
    }

    if (jobAds.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("لا توجد إعلانات مطابقة لهذا القطاع حالياً.")
        }
      }
    } else {
      items(jobAds, key = { it.id }) { job ->
        JobDetailedCard(
          job = job,
          isAdmin = isAdmin,
          onDelete = { viewModel.deleteJobAnnouncement(job) },
          onOrderRegistration = {
            viewModel.submitServiceRequest(
              serviceCategory = "التسجيلات الإدارية والمسابقات",
              serviceTitle = job.title,
              customerName = "زبون مهتم",
              customerPhone = "0664751271",
              details = "طلب التكفل بملف مسابقة: ${job.title} - ${job.employer}",
              options = "إعداد ملف ورقمي بالمكتبة",
              estimatedPriceDzd = 300.0
            )
          }
        )
      }
    }
  }
}

@Composable
fun JobDetailedCard(
  job: JobAnnouncement,
  isAdmin: Boolean,
  onDelete: () -> Unit,
  onOrderRegistration: () -> Unit
) {
  var isExpanded by remember { mutableStateOf(false) }

  ElevatedCard(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = EmeraldGreen.copy(alpha = 0.12f)
        ) {
          Text(
            text = job.sector,
            color = EmeraldGreen,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (job.isUrgent) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
            ) {
              Text(
                text = "هام / عاجل",
                color = MaterialTheme.colorScheme.error,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }
          if (isAdmin) {
            IconButton(onClick = onDelete) {
              Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = job.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "جهة التوظيف: ${job.employer}",
        style = MaterialTheme.typography.bodySmall,
        color = NavyPrimary,
        fontWeight = FontWeight.SemiBold
      )
      Text(
        text = "تاريخ الإعلان: ${job.datePosted} | آخر أجل: ${job.deadline}",
        style = MaterialTheme.typography.labelSmall,
        color = AmberGold
      )

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = job.description,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (job.conditions.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = NavyContainer.copy(alpha = 0.4f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("شروط المشاركة والمؤهلات:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NavyPrimary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(job.conditions, fontSize = 12.sp)
              }
            }
          }

          if (job.requiredFiles.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("الملف الإداري المطلوب تكوينه:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberGold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(job.requiredFiles, fontSize = 12.sp)
              }
            }
          }

          if (job.imageUrl.isNotBlank()) {
            Text(
              text = "رابط صورة الإعلان: ${job.imageUrl}",
              fontSize = 11.sp,
              color = NavyPrimary
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        TextButton(onClick = { isExpanded = !isExpanded }) {
          Text(if (isExpanded) "إخفاء التفاصيل" else "عرض الشروط والملف المطلوب")
        }

        Button(
          onClick = onOrderRegistration,
          colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("سجل في المكتبة", fontSize = 12.sp)
        }
      }
    }
  }
}

// --- Sub-Screen 2: الدروس والفيديوهات والملفات للعامة ---
@Composable
fun EducationalResourcesSubScreen(
  viewModel: MainViewModel,
  isAdmin: Boolean,
  onOpenAdd: () -> Unit
) {
  val resources by viewModel.educationalResources.collectAsState()
  val selectedLevel by viewModel.selectedAcademicLevel.collectAsState()
  val selectedType by viewModel.selectedResourceType.collectAsState()
  val context = LocalContext.current

  val levels = listOf("جميع المستويات", "ابتدائي", "متوسط", "ثانوي", "جامعي")
  val types = listOf("الكل", "ملف PDF", "فيديو تعليمي", "درس وملخص", "فرض واختبار")

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    if (isAdmin) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = AmberGold.copy(alpha = 0.12f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "خانة صاحب المكتبة لإضافة دروس وفيديوهات و PDF للعامة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = AmberGold
              )
              Text(
                text = "انشر ملفات PDF، فروض، اختبارات، أو روابط فيديوهات تعليمية ليستفيد منها الجميع.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
              )
            }
            Button(
              onClick = onOpenAdd,
              colors = ButtonDefaults.buttonColors(containerColor = AmberGold),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("إضافة ملف/فيديو", fontSize = 11.sp)
            }
          }
        }
      }
    }

    // Filter by Level
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("المستوى الدراسي:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(levels) { level ->
            val isSelected = selectedLevel == level
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.setSelectedAcademicLevel(level) },
              label = { Text(level) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = NavyPrimary,
                selectedLabelColor = Color.White
              )
            )
          }
        }
      }
    }

    // Filter by Resource Type
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("نوع المحتوى التعليمي:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(types) { t ->
            val isSelected = selectedType == t
            FilterChip(
              selected = isSelected,
              onClick = { viewModel.setSelectedResourceType(t) },
              label = { Text(t) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = AmberGold,
                selectedLabelColor = Color.White
              )
            )
          }
        }
      }
    }

    if (resources.isEmpty()) {
      item {
        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
          Text("لا توجد ملفات أو دروس مطابقة للمستوى المختار.")
        }
      }
    } else {
      items(resources, key = { it.id }) { resource ->
        EducationalResourceCard(
          resource = resource,
          isAdmin = isAdmin,
          onDelete = { viewModel.deleteEducationalResource(resource) },
          onOpenOrDownload = {
            openUrlOrDownload(context, resource.fileOrVideoUrl)
          },
          onOrderPrint = {
            viewModel.submitServiceRequest(
              serviceCategory = "خدمات الطباعة والبحوث",
              serviceTitle = "طباعة: ${resource.title}",
              customerName = "زبون المكتبة",
              customerPhone = "0664751271",
              details = "طلب سحب وطباعة ورقية للملف: ${resource.title} (${resource.subject})",
              options = "طباعة ليزرية للمراجعة",
              estimatedPriceDzd = 150.0
            )
          }
        )
      }
    }
  }
}

@Composable
fun EducationalResourceCard(
  resource: EducationalResource,
  isAdmin: Boolean,
  onDelete: () -> Unit,
  onOpenOrDownload: () -> Unit,
  onOrderPrint: () -> Unit
) {
  val isVideo = resource.resourceType == "فيديو تعليمي"

  ElevatedCard(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isVideo) Color(0xFFEF4444).copy(alpha = 0.12f) else NavyPrimary.copy(alpha = 0.12f)
          ) {
            Text(
              text = resource.resourceType,
              color = if (isVideo) Color(0xFFEF4444) else NavyPrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = AmberGold.copy(alpha = 0.12f)
          ) {
            Text(
              text = resource.academicLevel,
              color = AmberGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }

        if (isAdmin) {
          IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = resource.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "المادة: ${resource.subject} • ${resource.fileSizeOrDuration}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      if (resource.description.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = resource.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Order paper print
        TextButton(onClick = onOrderPrint) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("طلب طباعته ورقيًا بالمكتبة", fontSize = 11.sp)
        }

        Button(
          onClick = onOpenOrDownload,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isVideo) Color(0xFFDC2626) else NavyPrimary
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(
            imageVector = if (isVideo) Icons.Default.PlayCircle else Icons.Default.Download,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isVideo) "مشاهدة الفيديو" else "تحميل الـ PDF", fontSize = 12.sp)
        }
      }
    }
  }
}

private fun openUrlOrDownload(context: Context, url: String) {
  try {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
  } catch (e: Exception) {
    Toast.makeText(context, "الرابط: $url", Toast.LENGTH_SHORT).show()
  }
}
