package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.FlexyOrder
import kotlinx.coroutines.flow.Flow

@Dao
interface FlexyOrderDao {
  @Query("SELECT * FROM flexy_orders ORDER BY timestamp DESC")
  fun getAllOrders(): Flow<List<FlexyOrder>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: FlexyOrder): Long

  @Update
  suspend fun updateOrder(order: FlexyOrder)

  @Query("UPDATE flexy_orders SET status = :newStatus WHERE id = :orderId")
  suspend fun updateStatus(orderId: Long, newStatus: String)

  @Delete
  suspend fun deleteOrder(order: FlexyOrder)
}
