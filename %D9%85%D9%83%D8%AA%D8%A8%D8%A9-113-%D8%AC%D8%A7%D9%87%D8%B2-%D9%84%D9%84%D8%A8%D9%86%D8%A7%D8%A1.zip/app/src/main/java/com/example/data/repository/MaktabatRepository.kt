package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.EducationalResource
import com.example.data.model.FlexyOrder
import com.example.data.model.JobAnnouncement
import com.example.data.model.Product
import com.example.data.model.ServiceRequest
import com.example.data.remote.GeminiClient
import kotlinx.coroutines.flow.Flow

class MaktabatRepository(private val database: AppDatabase) {

  // Products
  val allProducts: Flow<List<Product>> = database.productDao().getAllProducts()

  fun getProductsByCategory(category: String): Flow<List<Product>> {
    return database.productDao().getProductsByCategory(category)
  }

  suspend fun updateProductPrice(productId: Long, newPrice: Double) {
    database.productDao().updateProductPrice(productId, newPrice)
  }

  suspend fun insertProduct(product: Product): Long {
    return database.productDao().insertProduct(product)
  }

  suspend fun deleteProduct(product: Product) {
    database.productDao().deleteProduct(product)
  }

  // Job Announcements
  val allJobAnnouncements: Flow<List<JobAnnouncement>> =
    database.jobAnnouncementDao().getAllAnnouncements()

  suspend fun insertJobAnnouncement(job: JobAnnouncement): Long {
    return database.jobAnnouncementDao().insertAnnouncement(job)
  }

  suspend fun deleteJobAnnouncement(job: JobAnnouncement) {
    database.jobAnnouncementDao().deleteAnnouncement(job)
  }

  // Educational Resources (Lessons, Videos, PDFs)
  val allEducationalResources: Flow<List<EducationalResource>> =
    database.educationalResourceDao().getAllResources()

  fun getResourcesByLevel(level: String): Flow<List<EducationalResource>> {
    return database.educationalResourceDao().getResourcesByLevel(level)
  }

  fun getResourcesByType(type: String): Flow<List<EducationalResource>> {
    return database.educationalResourceDao().getResourcesByType(type)
  }

  suspend fun insertEducationalResource(resource: EducationalResource): Long {
    return database.educationalResourceDao().insertResource(resource)
  }

  suspend fun deleteEducationalResource(resource: EducationalResource) {
    database.educationalResourceDao().deleteResource(resource)
  }

  // Service Requests (Printing, Typing, Registrations)
  val allServiceRequests: Flow<List<ServiceRequest>> =
    database.serviceRequestDao().getAllRequests()

  suspend fun submitServiceRequest(request: ServiceRequest): Long {
    return database.serviceRequestDao().insertRequest(request)
  }

  suspend fun updateServiceRequestStatus(id: Long, status: String) {
    database.serviceRequestDao().updateStatus(id, status)
  }

  // Flexy & Bill Orders
  val allFlexyOrders: Flow<List<FlexyOrder>> =
    database.flexyOrderDao().getAllOrders()

  suspend fun submitFlexyOrder(order: FlexyOrder): Long {
    return database.flexyOrderDao().insertOrder(order)
  }

  suspend fun updateFlexyOrderStatus(id: Long, status: String) {
    database.flexyOrderDao().updateStatus(id, status)
  }

  // Gemini AI Assistant
  suspend fun askAi(prompt: String): Result<String> {
    return GeminiClient.askAssistant(prompt)
  }
}
