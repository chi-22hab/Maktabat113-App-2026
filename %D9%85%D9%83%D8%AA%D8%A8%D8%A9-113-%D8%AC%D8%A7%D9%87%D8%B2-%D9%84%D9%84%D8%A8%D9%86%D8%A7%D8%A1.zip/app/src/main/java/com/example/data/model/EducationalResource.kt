package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "educational_resources")
data class EducationalResource(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val academicLevel: String, // "ابتدائي", "متوسط", "ثانوي", "جامعي"
  val subject: String, // رياضيات، لغة عربية، علوم، فيزياء، قانون، إعلام آلي...
  val resourceType: String, // "ملف PDF", "فيديو تعليمي", "درس وملخص", "فرض واختبار"
  val description: String,
  val fileOrVideoUrl: String,
  val fileSizeOrDuration: String = "",
  val dateAdded: String = ""
)

enum class AcademicLevel(val labelAr: String) {
  ALL("جميع المستويات"),
  PRIMARY("الطور الابتدائي"),
  MIDDLE("الطور المتوسط"),
  HIGH_SCHOOL("الطور الثانوي (BAC)"),
  UNIVERSITY("الطور الجامعي")
}
