package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.EducationalResource
import com.example.data.model.FlexyOrder
import com.example.data.model.JobAnnouncement
import com.example.data.model.Product
import com.example.data.model.ServiceRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    Product::class,
    JobAnnouncement::class,
    EducationalResource::class,
    ServiceRequest::class,
    FlexyOrder::class
  ],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun productDao(): ProductDao
  abstract fun jobAnnouncementDao(): JobAnnouncementDao
  abstract fun educationalResourceDao(): EducationalResourceDao
  abstract fun serviceRequestDao(): ServiceRequestDao
  abstract fun flexyOrderDao(): FlexyOrderDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "maktabat113_database"
        )
          .fallbackToDestructiveMigration()
          .addCallback(DatabaseCallback(scope))
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database)
          }
        }
      }
    }

    private suspend fun populateInitialData(database: AppDatabase) {
      val productDao = database.productDao()
      val jobDao = database.jobAnnouncementDao()
      val resourceDao = database.educationalResourceDao()

      // Initial Products with realistic Algerian prices (DZD)
      val initialProducts = listOf(
        // أدوات مدرسية
        Product(
          name = "علبة أقلام جافة فاخرة (4 ألوان)",
          category = "أدوات مدرسية",
          priceDzd = 180.0,
          description = "أقلام كتابة سلسة ومريحة للطلاب مع حبر يدوم طويلاً (أزرق، أسود، أحمر، أخضر).",
          inStock = true
        ),
        Product(
          name = "طقم أدوات هندسية متكامل مع فرجار معدني",
          category = "أدوات مدرسية",
          priceDzd = 450.0,
          description = "مسطرة 20 سم، كوسان، منقلة، ممحاة ومبراة في علبة معدنية محكمة.",
          inStock = true
        ),
        Product(
          name = "محفظة أقلام مدرسية قماشية مزدوجة",
          category = "أدوات مدرسية",
          priceDzd = 650.0,
          description = "مقلمة عصرية تتسع لجميع الأقلام والألوان بتصميم شبابي ومقاوم للتمزق.",
          inStock = true
        ),
        Product(
          name = "علبة ألوان خشبية 24 لون مائية",
          category = "أدوات مدرسية",
          priceDzd = 550.0,
          description = "ألوان غنية وواضحة ممتازة للرسم والأشغال اليدوية المدرسية.",
          inStock = true
        ),

        // كراريس وأغلفة
        Product(
          name = "كراس 96 صفحة مسطر خط كبير (سيبا)",
          category = "كراريس وأغلفة",
          priceDzd = 95.0,
          description = "ورق أبيض ناصع 70 غرام ممتاز للكتابة والتنظيم المدرسي.",
          inStock = true
        ),
        Product(
          name = "كراس أعمال تطبيقية 64 صفحة كبيـر (TP)",
          category = "كراريس وأغلفة",
          priceDzd = 140.0,
          description = "صفحة مسطرة وصفحة بيضاء للرسم العلمي والتجارب.",
          inStock = true
        ),
        Product(
          name = "كراس جامعي مسلك 200 صفحة مقسم 4 أقسام",
          category = "كراريس وأغلفة",
          priceDzd = 480.0,
          description = "غلاف بلاستيكي متين مع فواصل ملونة لتنظيم المحاضرات والدروس.",
          inStock = true
        ),
        Product(
          name = "مجموعة 10 أغلفة كراريس بلاستيكية شفافة وملونة",
          category = "كراريس وأغلفة",
          priceDzd = 200.0,
          description = "حماية مثالية للكراريس من التلف والأوساخ بألوان زاهية وجميلة.",
          inStock = true
        ),

        // كتب ومراجع
        Product(
          name = "سلسلة الموفق في البكالوريا - الرياضيات والفيزياء",
          category = "كتب ومراجع",
          priceDzd = 850.0,
          description = "ملخصات شاملة، حلول البكالوريات السابقة، وتمارين نموذجية مقترحة بالحل المفصل.",
          inStock = true
        ),
        Product(
          name = "كتاب المراجعة النهائية في الفلسفة واللغة العربية - 3 ثانوي",
          category = "كتب ومراجع",
          priceDzd = 780.0,
          description = "منهجيات كتابة المقالات الفلسفية وتحليل النصوص مع نماذج وزارية معتمدة.",
          inStock = true
        ),
        Product(
          name = "سلسلة التحدي لشهادة التعليم المتوسط (BEM)",
          category = "كتب ومراجع",
          priceDzd = 690.0,
          description = "دليل التلميذ المتفوق للاستعداد لشهادة التعليم المتوسط في جميع المواد.",
          inStock = true
        ),
        Product(
          name = "المصحف الشريف برواية ورش عن نافع (تجويد ملون)",
          category = "كتب ومراجع",
          priceDzd = 1200.0,
          description = "طباعة جزائرية فاخرة وورق أصفر مريح للعين مع تفسير الكلمات.",
          inStock = true
        ),

        // كوسميتيك وروائح
        Product(
          name = "عطر رويال عود مركز ومميز 50 مل",
          category = "كوسميتيك وروائح",
          priceDzd = 1500.0,
          description = "رائحة شرقية فاخرة ثباتية عالية تدوم أكثر من 24 ساعة.",
          inStock = true
        ),
        Product(
          name = "معطر جسم نسائي فلورال مسك رول أون",
          category = "كوسميتيك وروائح",
          priceDzd = 450.0,
          description = "انتعاش طبيعي ومكونات لطيفة على البشرة طوال اليوم.",
          inStock = true
        ),
        Product(
          name = "مرطب يدين وشفايف بزبدة الشيا الطبيعية",
          category = "كوسميتيك وروائح",
          priceDzd = 380.0,
          description = "ترطيب عميق وحماية من الجفاف والتشققات في كل الأوقات.",
          inStock = true
        ),

        // حلويات ومأكولات
        Product(
          name = "لوح شوكولاتة ماكسي بالبندق المقرمش 100 غرام",
          category = "حلويات ومأكولات",
          priceDzd = 220.0,
          description = "طعم الشوكولاتة الغني مع حبات البندق اللذيذة كاستراحة للدراسة.",
          inStock = true
        ),
        Product(
          name = "بسكويت محشو بالكريمة والشوكولاتة (حجم عائلي)",
          category = "حلويات ومأكولات",
          priceDzd = 150.0,
          description = "وجبة خفيفة ومقرمشة ومثالية مع القهوة أو الشاي.",
          inStock = true
        ),
        Product(
          name = "عصير فواكه طبيعي منعش 250 مل",
          category = "حلويات ومأكولات",
          priceDzd = 90.0,
          description = "طاقة وانتعاش فوري أثناء المراجعة وساعات المذاكرة.",
          inStock = true
        )
      )
      productDao.insertAll(initialProducts)

      // Initial Job Announcements
      val initialJobs = listOf(
        JobAnnouncement(
          title = "مسابقة توظيف الأساتذة في قطاع التربية الوطنية 2026",
          employer = "وزارة التربية الوطنية",
          sector = "قطاع التربية الوطنية",
          datePosted = "2026-10-15",
          deadline = "2026-11-10",
          description = "فتح مسابقة التوظيف على أساس الشهادة والاختبارات لرتب: أستاذ التعليم الثانوي، أستاذ التعليم المتوسط، وأستاذ المدرسة الابتدائية.",
          conditions = "شهادة الليسانس أو الماستر في التخصصات المطلوبة (رياضيات، لغات، علوم، فيزياء، تاريخ وجغرافيا).",
          requiredFiles = "طلب خطي، استمارة التسجيل الإلكتروني، نسخة من المؤهل، شهادة الإقامة، وشهادة السوابق العدلية (متوفر الاستخراج والتجهيز بمكتبة 113).",
          isUrgent = true
        ),
        JobAnnouncement(
          title = "مسابقة توظيف الأعوان الإداريين والأسلاك المشتركة",
          employer = "المديرية العامة للوظيفة العمومية",
          sector = "الإدارة العمومية",
          datePosted = "2026-10-18",
          deadline = "2026-11-05",
          description = "توظيف أعوان إدارة، متصرفين إداريين، أعوان حفظ البيانات، ومساعدين تقنيين بالمصالح المركزية والمحلية.",
          conditions = "المستوى الدراسي المطلوب من الثالثة ثانوي إلى ليسانس/ماستر في العلوم الاقتصادية والتسيير والعلوم القانونية.",
          requiredFiles = "ملف كامل مع صور شمسية وحوالة حقوق المشاركة وملف الإقامة المتاح سحبه والتسجيل به في مكتبة 113.",
          isUrgent = false
        ),
        JobAnnouncement(
          title = "تأكيد واستكمال ملفات المكتتبين في سكنات عدل (AADL)",
          employer = "الوكالة الوطنية لتحسين السكن وتطويره عدل",
          sector = "سكن عدل وغيرها",
          datePosted = "2026-10-20",
          deadline = "2026-11-25",
          description = "دعوة المكتتبين لتحديث بياناتهم وتحميل الوثائق الإدارية وكشوف الرواتب عبر المنصة الرقمية الرسمية.",
          conditions = "أن يكون المكتتب مسجلاً سابقاً ولديه رمز الدخول وكلمة المرور الخاصة به.",
          requiredFiles = "كشف الراتب الأخير، شهادة السلبية، وشهادة الميلاد الأصلية (نقوم بالتحميل والرقمنة والمتابعة بمكتبتنا).",
          isUrgent = true
        ),
        JobAnnouncement(
          title = "افتتاح التسجيلات في التكوين المهني ودورات المراسلة ONEFD",
          employer = "وزارة التكوين والتعليم المهنيين والديوان الوطني ONEFD",
          sector = "التكوين المهني",
          datePosted = "2026-10-10",
          deadline = "2026-11-15",
          description = "فرص التسجيل في تخصصات تقني سامي، إعلام آلي، ومتابعة الدروس بالمراسلة لجميع المستويات التعليمية.",
          conditions = "مفتوح لجميع الفئات مع إمكانية التعليم المتواصل والتكوين الإقامي أو الحضوري.",
          requiredFiles = "الشهادة المدرسية الأصلية، شهادة الميلاد، صور شمسية، واستمارة التسجيل الرسمية الصادرة من المكتبة.",
          isUrgent = false
        )
      )
      jobDao.insertAll(initialJobs)

      // Initial Educational Resources (PDFs, Lessons, Video Tutorials, Mock Exams)
      val initialResources = listOf(
        EducationalResource(
          title = "موضوع مقترح بكالوريا 2026 مع الحل النموذجي المفصل في الرياضيات",
          academicLevel = "ثانوي",
          subject = "رياضيات",
          resourceType = "فرض واختبار",
          description = "موضوع شامل للدوال الأسية واللوغاريتمية والمتتاليات العددية والهندسة الفضائية أعده نخبة من أساتذة التعليم الثانوي.",
          fileOrVideoUrl = "https://example.com/bac_math_2026.pdf",
          fileSizeOrDuration = "3.2 MB (PDF)",
          dateAdded = "2026-10-18"
        ),
        EducationalResource(
          title = "فيديو شرح شامل: منهجية الإجابة وتحليل النصوص في مادة الفلسفة للبكالوريا",
          academicLevel = "ثانوي",
          subject = "فلسفة",
          resourceType = "فيديو تعليمي",
          description = "درس مصور بالفيديو يشرح المقارنة، الجدلية، والاستقصاء بالوضع خطوة بخطوة لضمان علامة ممتازة.",
          fileOrVideoUrl = "https://youtube.com/watch?v=sample_philo_bac",
          fileSizeOrDuration = "28 دقيقة (فيديو)",
          dateAdded = "2026-10-19"
        ),
        EducationalResource(
          title = "سلسلة فروض واختبارات الفصل الأول للرابعة متوسط (BEM) في العلوم الفيزيائية",
          academicLevel = "متوسط",
          subject = "فيزياء",
          resourceType = "ملف PDF",
          description = "تمارين الظواهر الكهربائية، المادة وتحولاتها، مع تصحيح نموذجي متاح للطبع الفوري بالمكتبة.",
          fileOrVideoUrl = "https://example.com/bem_physique_prep.pdf",
          fileSizeOrDuration = "2.1 MB (PDF)",
          dateAdded = "2026-10-17"
        ),
        EducationalResource(
          title = "دليل الطالب لإعداد مذكرات التخرج الجامعية وقوالب Word جاهزة للتنسيق",
          academicLevel = "جامعي",
          subject = "إعلام آلي وبحوث",
          resourceType = "درس وملخص",
          description = "شرح معايير التهميش والتوثيق الأكاديمي APA، تنسيق الفصول، ومراجعة السرقة العلمية وكتابة التقارير.",
          fileOrVideoUrl = "https://example.com/thesis_guide_word_templates.zip",
          fileSizeOrDuration = "5.8 MB (ملف + قالب)",
          dateAdded = "2026-10-14"
        ),
        EducationalResource(
          title = "ملخص دروس وتمارين داعمة في اللغة العربية والرياضيات للسنة الخامسة ابتدائي",
          academicLevel = "ابتدائي",
          subject = "لغة عربية ورياضيات",
          resourceType = "ملف PDF",
          description = "مراجعة مبسطة وملونة لتلاميذ الطور الابتدائي تحضيراً للامتحانات الفصلية والتقييم الدوري.",
          fileOrVideoUrl = "https://example.com/primary_grade5_summary.pdf",
          fileSizeOrDuration = "1.5 MB (PDF)",
          dateAdded = "2026-10-16"
        ),
        EducationalResource(
          title = "فيديو تطبيقي: كيفية التسجيل في مسابقات الوظيفة العمومية وملء الاستمارات بدقة",
          academicLevel = "جامعي",
          subject = "إرشاد وتوظيف",
          resourceType = "فيديو تعليمي",
          description = "دليل مرئي يوضح طريقة ملء بطاقة المعلومات على أساس الشهادة بدون أخطاء واستيفاء الشروط.",
          fileOrVideoUrl = "https://youtube.com/watch?v=sample_concours_guide",
          fileSizeOrDuration = "18 دقيقة (فيديو)",
          dateAdded = "2026-10-20"
        )
      )
      resourceDao.insertAll(initialResources)
    }
  }
}
