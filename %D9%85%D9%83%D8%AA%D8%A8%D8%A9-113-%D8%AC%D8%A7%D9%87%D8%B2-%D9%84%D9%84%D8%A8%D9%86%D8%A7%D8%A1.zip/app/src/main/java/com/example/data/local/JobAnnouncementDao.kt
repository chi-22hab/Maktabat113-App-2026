package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.JobAnnouncement
import kotlinx.coroutines.flow.Flow

@Dao
interface JobAnnouncementDao {
  @Query("SELECT * FROM job_announcements ORDER BY id DESC")
  fun getAllAnnouncements(): Flow<List<JobAnnouncement>>

  @Query("SELECT * FROM job_announcements WHERE sector = :sector ORDER BY id DESC")
  fun getAnnouncementsBySector(sector: String): Flow<List<JobAnnouncement>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAnnouncement(job: JobAnnouncement): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(jobs: List<JobAnnouncement>)

  @Update
  suspend fun updateAnnouncement(job: JobAnnouncement)

  @Delete
  suspend fun deleteAnnouncement(job: JobAnnouncement)

  @Query("SELECT COUNT(*) FROM job_announcements")
  suspend fun count(): Int
}
