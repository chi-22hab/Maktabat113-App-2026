package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ServiceRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceRequestDao {
  @Query("SELECT * FROM service_requests ORDER BY timestamp DESC")
  fun getAllRequests(): Flow<List<ServiceRequest>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRequest(request: ServiceRequest): Long

  @Update
  suspend fun updateRequest(request: ServiceRequest)

  @Query("UPDATE service_requests SET status = :newStatus WHERE id = :requestId")
  suspend fun updateStatus(requestId: Long, newStatus: String)

  @Delete
  suspend fun deleteRequest(request: ServiceRequest)
}
