package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "job_announcements")
data class JobAnnouncement(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val employer: String,
  val sector: String, // "قطاع التربية الوطنية", "التعليم العالي", "الإدارة العمومية", "التكوين المهني", "سكن عدل وغيرها"
  val datePosted: String,
  val deadline: String,
  val description: String,
  val conditions: String,
  val requiredFiles: String,
  val imageUrl: String = "",
  val externalLink: String = "",
  val isUrgent: Boolean = false
)
