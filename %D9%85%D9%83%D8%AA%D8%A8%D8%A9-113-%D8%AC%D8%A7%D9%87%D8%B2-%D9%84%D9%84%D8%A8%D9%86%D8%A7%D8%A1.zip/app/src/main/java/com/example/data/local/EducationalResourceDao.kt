package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EducationalResource
import kotlinx.coroutines.flow.Flow

@Dao
interface EducationalResourceDao {
  @Query("SELECT * FROM educational_resources ORDER BY id DESC")
  fun getAllResources(): Flow<List<EducationalResource>>

  @Query("SELECT * FROM educational_resources WHERE academicLevel = :level ORDER BY id DESC")
  fun getResourcesByLevel(level: String): Flow<List<EducationalResource>>

  @Query("SELECT * FROM educational_resources WHERE resourceType = :type ORDER BY id DESC")
  fun getResourcesByType(type: String): Flow<List<EducationalResource>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertResource(resource: EducationalResource): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(resources: List<EducationalResource>)

  @Update
  suspend fun updateResource(resource: EducationalResource)

  @Delete
  suspend fun deleteResource(resource: EducationalResource)

  @Query("SELECT COUNT(*) FROM educational_resources")
  suspend fun count(): Int
}
