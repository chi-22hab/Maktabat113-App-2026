package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Product
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
  @Query("SELECT * FROM products ORDER BY id DESC")
  fun getAllProducts(): Flow<List<Product>>

  @Query("SELECT * FROM products WHERE category = :category ORDER BY id DESC")
  fun getProductsByCategory(category: String): Flow<List<Product>>

  @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
  suspend fun getProductById(id: Long): Product?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduct(product: Product): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(products: List<Product>)

  @Update
  suspend fun updateProduct(product: Product)

  @Query("UPDATE products SET priceDzd = :newPrice WHERE id = :productId")
  suspend fun updateProductPrice(productId: Long, newPrice: Double)

  @Delete
  suspend fun deleteProduct(product: Product)

  @Query("SELECT COUNT(*) FROM products")
  suspend fun count(): Int
}
