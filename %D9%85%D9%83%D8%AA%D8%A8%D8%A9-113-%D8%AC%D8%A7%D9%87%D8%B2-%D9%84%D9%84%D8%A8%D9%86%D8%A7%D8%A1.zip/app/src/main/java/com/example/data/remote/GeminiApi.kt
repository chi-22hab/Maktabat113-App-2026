package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
  val contents: List<GeminiContent>,
  val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
  val parts: List<GeminiPart>,
  val role: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
  val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
  val candidates: List<GeminiCandidate>? = null,
  val error: GeminiError? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
  val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiError(
  val code: Int? = null,
  val message: String? = null,
  val status: String? = null
)

interface GeminiService {
  @POST("v1beta/models/gemini-3.5-flash:generateContent")
  suspend fun generateContent(
    @Query("key") apiKey: String,
    @Body request: GeminiRequest
  ): GeminiResponse
}

object GeminiClient {
  private const val BASE_URL = "https://generativelanguage.googleapis.com/"

  private val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .addInterceptor(HttpLoggingInterceptor().apply {
      level = HttpLoggingInterceptor.Level.BASIC
    })
    .build()

  private val moshi = Moshi.Builder()
    .addLast(KotlinJsonAdapterFactory())
    .build()

  private val service: GeminiService by lazy {
    Retrofit.Builder()
      .baseUrl(BASE_URL)
      .client(okHttpClient)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(GeminiService::class.java)
  }

  suspend fun askAssistant(prompt: String): Result<String> = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
      // Fallback response with helpful academic advice
      return@withContext Result.success(getSmartAcademicFallback(prompt))
    }

    val systemInstruction = GeminiContent(
      parts = listOf(
        GeminiPart(
          """
          أنت المستشار والمساعد الأكاديمي والذكي لمكتبة 113 (Maktabat 113) الواقعة في حي 113، هاتف 0664751271، إيميل mactabat113@gmail.com.
          مهامك:
          1. مساعدة التلاميذ (ابتدائي، متوسط، ثانوي، بكالوريا) والطلبة الجامعيين في شرح الدروس، تلخيص المقالات، حل المسائل، إعداد خطط البحوث ومذكرات التخرج.
          2. تقديم نصائح ومعلومات وافية حول مسابقات التوظيف في الجزائر (أساتذة، أعوان إدارة، أسلاك مشتركة) وشروط ملفاتها.
          3. شرح خطوات تسجيلات البكالوريا (BAC)، شهادة التعليم المتوسط (BEM)، وسكنات عدل (AADL)، والتكوين المهني والمراسلة ONEFD.
          4. إرشاد الزبائن حول خدمات الطباعة والخدمات الرقمية المتوفرة بمكتبة 113 بحي 113.
          كن دقيقاً، مهذباً، منظماً برؤوس أقلام واضحة وباللغة العربية الفصحى.
          """.trimIndent()
        )
      )
    )

    val request = GeminiRequest(
      contents = listOf(
        GeminiContent(
          parts = listOf(GeminiPart(prompt))
        )
      ),
      systemInstruction = systemInstruction
    )

    try {
      val response = service.generateContent(apiKey, request)
      val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
      if (!reply.isNullOrBlank()) {
        Result.success(reply)
      } else {
        val err = response.error?.message ?: "لم يتم استلام رد من نموذج الذكاء الاصطناعي."
        Result.success("تنبيه: $err\n\n${getSmartAcademicFallback(prompt)}")
      }
    } catch (e: Exception) {
      Result.success(getSmartAcademicFallback(prompt))
    }
  }

  private fun getSmartAcademicFallback(prompt: String): String {
    val p = prompt.lowercase()
    return when {
      p.contains("بحث") || p.contains("مذكرة") || p.contains("تخرج") -> {
        """
        📚 **إرشادات إعداد البحوث والمذكرات الجامعية من مكتبة 113:**
        1. **اختيار الموضوع:** حدد إشكالية واضحة ومحددة زمنياً وجغرافياً.
        2. **خطة البحث النموذجية:**
           - المقدمة: تمهيد، طرح الإشكالية، الفرضيات، وأهمية الموضوع.
           - الفصل الأول: الإطار المفاهيمي والنظري.
           - الفصل الثاني: الجانب التطبيقي أو دراسة الحالة.
           - الخاتمة: النتائج والتوصيات.
        3. **خدمة مكتبة 113:** نوفر لك كتابة المذكرات، تنسيق وتهميش المراجع حسب معايير APA، وطباعة وتجليد فاخر بحي 113.
        """.trimIndent()
      }
      p.contains("توظيف") || p.contains("مسابقة") || p.contains("أستاذ") || p.contains("إدارة") -> {
        """
        📋 **دليل مسابقات التوظيف والأسلاك الإدارية (الجزائر):**
        - **الملف المطلوب عادة:** استمارة المعلومات على أساس الشهادة أو الاختبار، نسخة من المؤهل العلمي، شهادة الإقامة، وشهادة السوابق العدلية.
        - **طريقة التحضير:** مراجعة القوانين الأساسية للوظيفة العمومية (الأمر 06-03)، الثقافة العامة وتاريخ الجزائر، وتقنيات التحرير الإداري.
        - **خدمة مكتبة 113:** سحب الاستمارات، التسجيل عبر المنصات الرقمية، وطباعة وإعداد الملفات كاملة. تواصل معنا: 0664751271.
        """.trimIndent()
      }
      p.contains("سكن") || p.contains("عدل") || p.contains("aadl") -> {
        """
        🏠 **إرشادات ملفات وتسجيلات سكنات عدل AADL:**
        - تأكد من تجهيز رقم التعريف الوطني (NIN) ورقم بطاقة الشفاء.
        - استخراج شهادة السلبية وآخر كشف للراتب الشهري للمكتتب والزوج(ة).
        - **خدمة مكتبة 113:** نقوم برفع وتحديث وثائقكم على المنصة الرقمية ومتابعة حالة الملف بدقة واحترافية.
        """.trimIndent()
      }
      p.contains("فليكسي") || p.contains("دفع") || p.contains("بريدي") -> {
        """
        💳 **خدمات الشحن والدفع الرقمي بمكتبة 113:**
        - فليكسي فوري: جيزي، موبيليس، أوريدو.
        - شحن الإنترنت: اتصالات الجزائر Idoom Fibre / 4G / ADSL.
        - دفع الفواتير: سونلغاز، المياه، والهاتف الثابت.
        - الدفع عبر بريدي موب، الحساب البريدي الجاري، البطاقة الذهبية، أو بالعملات (يورو / دينار تونسي).
        """.trimIndent()
      }
      else -> {
        """
        ✨ **مرحباً بك في المستشار الذكي لمكتبة 113!**
        نحن هنا لخدمتك ومساعدتك في دراستك وبحوثك وجميع معاملاتك الإدارية.
        - للمساعدة في حل تمرين، تلخيص درس، أو كتابة مقال، اكتب سؤالك بالتفصيل.
        - لمتابعة خدمات الطباعة والتسجيلات، يمكنك التوجه إلى قسم الخدمات أو زيارتنا بحي 113.
        - رقم هاتف المكتبة المباشر: **0664751271**
        - البريد الإلكتروني: **mactabat113@gmail.com**
        """.trimIndent()
      }
    }
  }
}
