package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_requests")
data class ServiceRequest(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val serviceCategory: String, // "خدمات الطباعة والبحوث", "التسجيلات الإدارية والمسابقات"
  val serviceTitle: String, // "طباعة بحوث ومذكرات", "تسجيل مسابقة الأساتذة", "تسجيل سكن عدل", etc.
  val customerName: String,
  val customerPhone: String,
  val details: String,
  val options: String = "", // "ألوان / أبيض وأسود / تغليف حراري / عدد النسخ"
  val estimatedPriceDzd: Double = 0.0,
  val status: String = "جديد", // "جديد", "قيد المعالجة", "جاهز للاستلام"
  val timestamp: Long = System.currentTimeMillis()
)
