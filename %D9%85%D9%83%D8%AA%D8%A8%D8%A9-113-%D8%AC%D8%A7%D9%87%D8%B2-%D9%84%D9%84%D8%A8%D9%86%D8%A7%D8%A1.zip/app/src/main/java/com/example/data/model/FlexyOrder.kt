package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "flexy_orders")
data class FlexyOrder(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val serviceName: String, // "جيزي Djezzy", "موبيليس Mobilis", "أوريدو Ooredoo", "Idoom Fibre", "فاتورة سونلغاز", "فاتورة المياه", "الهاتف الثابت"
  val targetIdentifier: String, // رقم الهاتف أو رقم الفاتورة أو حساب العقد
  val amount: Double,
  val currency: String, // "دج (DZD)", "أورو (€)", "دينار تونسي (TND)"
  val paymentMethod: String, // "بريدي موب (BaridiMob)", "حساب CCP", "البطاقة الذهبية", "الدفع بالمكتبة"
  val senderPhone: String,
  val transactionReference: String = "",
  val status: String = "قيد المعالجة",
  val timestamp: Long = System.currentTimeMillis()
)
