package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val name: String,
  val category: String, // "أدوات مدرسية", "كراريس وأغلفة", "كتب ومراجع", "كوسميتيك وروائح", "حلويات ومأكولات"
  val priceDzd: Double,
  val description: String,
  val imageUrl: String = "",
  val inStock: Boolean = true
)

enum class ProductCategory(val titleAr: String) {
  ALL("الكل"),
  SCHOOL_SUPPLIES("أدوات مدرسية"),
  NOTEBOOKS("كراريس وأغلفة"),
  BOOKS("كتب ومراجع"),
  COSMETICS("كوسميتيك وروائح"),
  SWEETS("حلويات ومأكولات")
}
